import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Build output → ../static/  (FastAPI จะ serve จากนี่)
export default defineConfig({
  plugins: [react()],
  build: {
    outDir: "../static",   // → platform/static/
    emptyOutDir: true,
    sourcemap: false,
  },
  server: {
    port: 3000,
    proxy: {
      "/api": "http://localhost:8000",
      "/admin": "http://localhost:8000",
      "/webhook": "http://localhost:8000",
    },
  },
});
