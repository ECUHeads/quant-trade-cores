/**
 * Quant Agent Dashboard — App.jsx
 * ================================
 * Mock data mode: ใช้ MOCK_* constants
 * API  mode:      เปลี่ยน USE_API = true → fetch จาก FastAPI
 *
 * Toggle ได้ที่ตัวแปร USE_API ข้างล่าง
 */

import { useState, useEffect, useCallback, useMemo } from "react";
import {
  AreaChart, Area, BarChart, Bar, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from "recharts";

// ═══════════════════════════════════════════════════════════
// CONFIG — เปลี่ยน USE_API = true เมื่อ backend พร้อม
// ═══════════════════════════════════════════════════════════
const USE_API = false;
const API_BASE = window.location.origin;  // same-origin (FastAPI serve ทั้ง API + static)

// ═══════════════════════════════════════════════════════════
// API LAYER — จะใช้เมื่อ USE_API = true
// ═══════════════════════════════════════════════════════════
async function apiFetch(path, opts = {}) {
  const token = localStorage.getItem("jwt_token");
  const headers = { "Content-Type": "application/json", ...opts.headers };
  if (token) headers["Authorization"] = `Bearer ${token}`;

  const res = await fetch(`${API_BASE}${path}`, { ...opts, headers });
  if (!res.ok) throw new Error(`API ${res.status}: ${await res.text()}`);
  return res.json();
}

const api = {
  getSignals:     (limit = 20) => apiFetch(`/api/signals?limit=${limit}`),
  getPerformance: ()           => apiFetch("/api/performance"),
  getHealth:      ()           => apiFetch("/api/health"),
  login:          (email, pw)  => apiFetch("/api/auth/login", {
    method: "POST", body: JSON.stringify({ email, password: pw }),
  }),
  adminStats:     (key)        => apiFetch("/admin/stats", {
    headers: { "X-Admin-Key": key },
  }),
  adminCancel:    (signalId, key) => apiFetch(`/admin/cancel/${signalId}`, {
    method: "POST", headers: { "X-Admin-Key": key },
  }),
};

// ═══════════════════════════════════════════════════════════
// MOCK DATA
// ═══════════════════════════════════════════════════════════

const MOCK_SIGNALS = [
  {
    signal_id: "SIG-20260319-001", asset: "NVDA", action: "BUY", side: "LONG",
    timestamp: "2026-03-19T14:30:00Z",
    pricing_zone: { entry_range: [182.0, 182.5], take_profit: 187.75, stop_loss: 179.56, risk_reward: "1:2.5" },
    strategy_type: "Trend Following", news_catalyst: "NVDA beats Q2 EPS by 15%, raises guidance",
    llm_cio_comment: "Strong earnings catalyst aligned with VWAP pullback. Low VIX environment favorable. Sector momentum confirmed by SMH breakout.",
    ml_score: 76, confidence: 0.81, gate19_action: "EXECUTE", status: "ACTIVE",
    regime: "RISK_ON", vix: 14.2,
  },
  {
    signal_id: "SIG-20260319-002", asset: "TSLA", action: "SELL", side: "SHORT",
    timestamp: "2026-03-19T13:45:00Z",
    pricing_zone: { entry_range: [245.0, 245.8], take_profit: 238.0, stop_loss: 249.5, risk_reward: "1:1.8" },
    strategy_type: "Mean Reversion", news_catalyst: "Tesla lowers Q3 delivery guidance",
    llm_cio_comment: "Negative catalyst confirmed by price action below VWAP. Reduced size due to elevated VIX.",
    ml_score: 68, confidence: 0.72, gate19_action: "REDUCE", status: "WON",
    pnl_usd: 156.40, regime: "RISK_ON", vix: 14.2,
  },
  {
    signal_id: "SIG-20260319-003", asset: "META", action: "BUY", side: "LONG",
    timestamp: "2026-03-19T10:15:00Z",
    pricing_zone: { entry_range: [520.0, 521.5], take_profit: 535.0, stop_loss: 515.0, risk_reward: "1:2.1" },
    strategy_type: "Trend Following", news_catalyst: "Goldman upgrades META to Buy, PT $600",
    llm_cio_comment: "Analyst upgrade with strong institutional flow. EXECUTE full size.",
    ml_score: 82, confidence: 0.88, gate19_action: "EXECUTE", status: "WON",
    pnl_usd: 287.50, regime: "RISK_ON", vix: 13.8,
  },
  {
    signal_id: "SIG-20260318-001", asset: "AMD", action: "BUY", side: "LONG",
    timestamp: "2026-03-18T11:00:00Z",
    pricing_zone: { entry_range: [165.0, 166.0], take_profit: 174.0, stop_loss: 162.0, risk_reward: "1:2.0" },
    strategy_type: "Trend Following", news_catalyst: "AMD announces new AI chip partnership with MSFT",
    llm_cio_comment: "Product launch catalyst. Sector momentum positive but entry slightly above VWAP.",
    ml_score: 71, confidence: 0.75, gate19_action: "EXECUTE", status: "LOST",
    pnl_usd: -89.20, regime: "NEUTRAL", vix: 16.1,
  },
  {
    signal_id: "SIG-20260317-001", asset: "AAPL", action: "BUY", side: "LONG",
    timestamp: "2026-03-17T09:45:00Z",
    pricing_zone: { entry_range: [198.0, 198.5], take_profit: 205.0, stop_loss: 195.5, risk_reward: "1:2.6" },
    strategy_type: "Trend Following", news_catalyst: "Apple Vision Pro sales exceed estimates",
    llm_cio_comment: "Confirmed breakout above 200-day MA. Strong volume profile. Full execution.",
    ml_score: 79, confidence: 0.84, gate19_action: "EXECUTE", status: "WON",
    pnl_usd: 198.30, regime: "RISK_ON", vix: 13.5,
  },
  {
    signal_id: "SIG-20260316-001", asset: "GOOG", action: "SELL", side: "SHORT",
    timestamp: "2026-03-16T14:20:00Z",
    pricing_zone: { entry_range: [172.0, 172.8], take_profit: 166.0, stop_loss: 175.5, risk_reward: "1:2.0" },
    strategy_type: "Mean Reversion", news_catalyst: "DOJ antitrust ruling adverse to Google Search",
    llm_cio_comment: "Regulatory headwind. Price rejected at upper Bollinger. Short with tight stop.",
    ml_score: 65, confidence: 0.69, gate19_action: "REDUCE", status: "WON",
    pnl_usd: 112.60, regime: "NEUTRAL", vix: 15.9,
  },
];

const generateEquityCurve = () => {
  const data = [];
  let equity = 5000;
  const days = ["Mon", "Tue", "Wed", "Thu", "Fri"];
  for (let w = 0; w < 4; w++) {
    for (let d = 0; d < 5; d++) {
      const pnl = Math.floor(Math.random() * 120 - 35);
      equity += pnl;
      data.push({ date: `W${w + 1} ${days[d]}`, equity: Math.round(equity * 100) / 100, pnl });
    }
  }
  return data;
};

const MOCK_EQUITY = generateEquityCurve();

const MOCK_STATS = {
  total_signals: 47, active_signals: 1, win_rate_pct: 63.8,
  total_pnl_usd: 842.50, profit_factor: 2.14, max_drawdown_usd: 125.30,
  avg_rr: 2.1, winners: 30, losers: 17, sharpe: 1.87,
  avg_hold_min: 42, best_trade: 312.50, worst_trade: -98.40,
};

const MOCK_USERS = [
  { name: "trader_john", role: "VIP", line: true, tg: true, expires: "2026-04-19", trades: 28 },
  { name: "crypto_amy", role: "VIP", line: false, tg: true, expires: "2026-03-25", trades: 15 },
  { name: "quant_bob", role: "VIP", line: true, tg: true, expires: "2026-05-01", trades: 42 },
  { name: "newbie_99", role: "GUEST", line: true, tg: false, expires: null, trades: 0 },
  { name: "whale_sam", role: "ADMIN", line: true, tg: true, expires: null, trades: 47 },
];

// ═══════════════════════════════════════════════════════════
// THEME
// ═══════════════════════════════════════════════════════════

const T = {
  bg: "#060a10", card: "#0d1320", cardHover: "#111b2e",
  border: "#1a2540", accent: "#2d7aff", accentDim: "#2d7aff22",
  green: "#00d4aa", greenDim: "#00d4aa18",
  red: "#ff4757", redDim: "#ff475718",
  yellow: "#ffbe0b", yellowDim: "#ffbe0b18",
  purple: "#a855f7",
  text: "#e8edf5", textSec: "#8b9cc0", muted: "#4a5b80",
  surface: "#131d33",
};

const font = {
  display: "'Sora', 'SF Pro Display', -apple-system, sans-serif",
  mono: "'JetBrains Mono', 'Fira Code', 'SF Mono', monospace",
  body: "'DM Sans', 'SF Pro Text', -apple-system, sans-serif",
};

// ═══════════════════════════════════════════════════════════
// SMALL COMPONENTS
// ═══════════════════════════════════════════════════════════

function GlowDot({ color = T.green, size = 8 }) {
  return (
    <span style={{ position: "relative", display: "inline-block", width: size, height: size }}>
      <span style={{ position: "absolute", inset: -2, borderRadius: "50%", background: color, opacity: 0.3, animation: "glow-pulse 2s ease-in-out infinite" }} />
      <span style={{ position: "absolute", inset: 0, borderRadius: "50%", background: color }} />
    </span>
  );
}

function Badge({ children, color = T.accent }) {
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 4,
      background: color + "18", color, padding: "3px 10px",
      borderRadius: 6, fontSize: 11, fontWeight: 700, fontFamily: font.mono,
      letterSpacing: "0.02em", whiteSpace: "nowrap",
    }}>{children}</span>
  );
}

function StatCard({ label, value, sub, color = T.text, icon }) {
  return (
    <div style={{
      background: T.card, borderRadius: 14, border: `1px solid ${T.border}`,
      padding: "18px 20px", position: "relative", overflow: "hidden",
    }}>
      <div style={{ position: "absolute", top: 0, right: 0, width: 80, height: 80, background: `radial-gradient(circle at top right, ${color}08, transparent)` }} />
      <div style={{ fontSize: 11, color: T.muted, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 8, fontFamily: font.body }}>
        {icon && <span style={{ marginRight: 4 }}>{icon}</span>}{label}
      </div>
      <div style={{ fontSize: 26, fontWeight: 800, color, fontFamily: font.mono, lineHeight: 1.1 }}>{value}</div>
      {sub && <div style={{ fontSize: 11, color: T.muted, marginTop: 6, fontFamily: font.body }}>{sub}</div>}
    </div>
  );
}

function MiniTag({ children, color = T.muted }) {
  return (
    <span style={{ background: T.surface, color, padding: "3px 8px", borderRadius: 5, fontSize: 10, fontWeight: 600, fontFamily: font.mono }}>{children}</span>
  );
}

// ── Signal Card (Collapsible)
function SignalCard({ signal, isVip }) {
  const [expanded, setExpanded] = useState(false);
  const isBull = signal.side === "LONG";
  const accent = isBull ? T.green : T.red;
  const pz = signal.pricing_zone || {};
  const entry = pz.entry_range || [0, 0];
  const mid = (entry[0] + entry[1]) / 2;
  const tpPct = mid > 0 ? ((pz.take_profit - mid) / mid * 100).toFixed(1) : "0";
  const slPct = mid > 0 ? (Math.abs((pz.stop_loss - mid) / mid) * 100).toFixed(1) : "0";

  const statusConfig = {
    ACTIVE:    { bg: T.greenDim, color: T.green, label: "● LIVE" },
    WON:       { bg: T.greenDim, color: T.green, label: "✓ WON" },
    LOST:      { bg: T.redDim, color: T.red, label: "✗ LOST" },
    CANCELLED: { bg: T.yellowDim, color: T.yellow, label: "⊘ CANCELLED" },
  };
  const st = statusConfig[signal.status] || statusConfig.CANCELLED;

  return (
    <div onClick={() => setExpanded(!expanded)} style={{
      background: T.card, borderRadius: 14,
      border: `1px solid ${signal.status === "ACTIVE" ? accent + "44" : T.border}`,
      overflow: "hidden", marginBottom: 12, cursor: "pointer", transition: "all 0.2s ease",
    }}>
      {/* Header */}
      <div style={{
        padding: "14px 20px", display: "flex", justifyContent: "space-between", alignItems: "center",
        background: signal.status === "ACTIVE" ? `linear-gradient(135deg, ${accent}06, transparent)` : undefined,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <div style={{
            width: 48, height: 48, borderRadius: 12,
            background: `linear-gradient(135deg, ${accent}20, ${accent}08)`,
            border: `1px solid ${accent}30`,
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 13, fontWeight: 800, color: accent, fontFamily: font.mono,
          }}>{signal.asset}</div>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 2 }}>
              <span style={{ fontSize: 18, fontWeight: 800, color: T.text, fontFamily: font.display }}>{signal.asset}</span>
              <Badge color={isBull ? T.green : T.red}>{isBull ? "▲ LONG" : "▼ SHORT"}</Badge>
              {signal.status === "ACTIVE" && <GlowDot color={T.green} />}
            </div>
            <div style={{ fontSize: 11, color: T.muted, fontFamily: font.body }}>
              {signal.strategy_type} • {new Date(signal.timestamp).toLocaleString("th-TH", { hour: "2-digit", minute: "2-digit", day: "numeric", month: "short" })}
            </div>
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          {signal.pnl_usd !== undefined && (
            <span style={{ fontSize: 16, fontWeight: 800, fontFamily: font.mono, color: signal.pnl_usd >= 0 ? T.green : T.red }}>
              {signal.pnl_usd >= 0 ? "+" : ""}{signal.pnl_usd.toFixed(2)}
            </span>
          )}
          <span style={{ background: st.bg, color: st.color, padding: "5px 12px", borderRadius: 8, fontSize: 11, fontWeight: 700, fontFamily: font.mono }}>{st.label}</span>
        </div>
      </div>

      {/* Expanded */}
      {expanded && (
        <div style={{ borderTop: `1px solid ${T.border}` }}>
          <div style={{ padding: "14px 20px", display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16 }}>
            {[
              { label: "ENTRY ZONE", value: `$${entry[0].toFixed(2)} – $${entry[1].toFixed(2)}`, color: T.text },
              { label: "TAKE PROFIT", value: `$${pz.take_profit?.toFixed(2)}`, sub: `+${tpPct}%`, color: T.green },
              { label: "STOP LOSS", value: `$${pz.stop_loss?.toFixed(2)}`, sub: `-${slPct}%`, color: T.red },
              { label: "RISK:REWARD", value: pz.risk_reward, color: T.accent },
            ].map(p => (
              <div key={p.label}>
                <div style={{ fontSize: 10, color: T.muted, fontWeight: 600, marginBottom: 3, fontFamily: font.body }}>{p.label}</div>
                <div style={{ fontSize: 15, fontWeight: 700, color: p.color, fontFamily: font.mono }}>
                  {p.value} {p.sub && <span style={{ fontSize: 11, opacity: 0.7 }}>{p.sub}</span>}
                </div>
              </div>
            ))}
          </div>
          <div style={{ padding: "0 20px 12px", display: "flex", gap: 6, flexWrap: "wrap" }}>
            <MiniTag color={T.accent}>ML {signal.ml_score}</MiniTag>
            <MiniTag color={T.purple}>Conf {(signal.confidence * 100).toFixed(0)}%</MiniTag>
            <MiniTag color={signal.gate19_action === "EXECUTE" ? T.green : T.yellow}>G19 {signal.gate19_action}</MiniTag>
            {signal.regime && <MiniTag color={T.textSec}>{signal.regime}</MiniTag>}
            {signal.vix && <MiniTag color={signal.vix > 20 ? T.red : T.green}>VIX {signal.vix}</MiniTag>}
          </div>
          {signal.news_catalyst && (
            <div style={{ padding: "0 20px 12px", fontSize: 12, color: T.textSec, fontFamily: font.body, lineHeight: 1.5 }}>
              <span style={{ color: T.muted, fontWeight: 600 }}>Catalyst:</span> {signal.news_catalyst}
            </div>
          )}
          {isVip && signal.llm_cio_comment && (
            <div style={{ margin: "0 16px 14px", background: T.surface, borderRadius: 10, padding: "12px 16px", borderLeft: `3px solid ${T.accent}` }}>
              <div style={{ fontSize: 10, color: T.accent, fontWeight: 700, marginBottom: 4, fontFamily: font.mono, letterSpacing: "0.06em" }}>AI CIO ANALYSIS</div>
              <div style={{ fontSize: 12, color: T.textSec, lineHeight: 1.6, fontFamily: font.body }}>{signal.llm_cio_comment}</div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background: T.card, border: `1px solid ${T.border}`, borderRadius: 10, padding: "10px 14px", boxShadow: `0 8px 32px ${T.bg}cc` }}>
      <div style={{ fontSize: 11, color: T.muted, marginBottom: 4, fontFamily: font.body }}>{label}</div>
      {payload.map((p, i) => (
        <div key={i} style={{ fontSize: 14, fontWeight: 700, color: p.color || T.accent, fontFamily: font.mono }}>
          {p.name}: {typeof p.value === "number" ? (p.name === "pnl" ? (p.value >= 0 ? "+" : "") + p.value.toFixed(0) : "$" + p.value.toFixed(2)) : p.value}
        </div>
      ))}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// PAGES
// ═══════════════════════════════════════════════════════════

function SignalsPage({ signals, isVip }) {
  const active = signals.filter(s => s.status === "ACTIVE");
  const closed = signals.filter(s => s.status !== "ACTIVE");

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <div>
          <h1 style={{ fontSize: 22, fontWeight: 800, margin: 0, fontFamily: font.display }}>{isVip ? "Live Signal Feed" : "Signal History"}</h1>
          <p style={{ fontSize: 12, color: T.muted, margin: "4px 0 0", fontFamily: font.body }}>
            {isVip ? "Real-time signals from Quant Engine + AI CIO" : "Delayed signals (1hr) — upgrade to VIP for live feed"}
          </p>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <GlowDot color={T.green} /><span style={{ fontSize: 11, color: T.muted, fontFamily: font.mono }}>ENGINE ONLINE</span>
        </div>
      </div>

      {!isVip && (
        <div style={{ background: `linear-gradient(135deg, ${T.accent}10, ${T.purple}10)`, border: `1px solid ${T.accent}30`, borderRadius: 14, padding: "20px 24px", marginBottom: 20, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <div style={{ fontSize: 15, fontWeight: 700, color: T.text, fontFamily: font.display, marginBottom: 4 }}>Upgrade to VIP</div>
            <div style={{ fontSize: 12, color: T.muted, fontFamily: font.body }}>Real-time signals • AI CIO analysis • LINE/Telegram alerts</div>
          </div>
          <button style={{ background: `linear-gradient(135deg, ${T.accent}, ${T.purple})`, color: "#fff", border: "none", padding: "10px 24px", borderRadius: 10, cursor: "pointer", fontWeight: 700, fontSize: 13, fontFamily: font.body }}>฿999/เดือน</button>
        </div>
      )}

      {isVip && active.length > 0 && (
        <div style={{ marginBottom: 8 }}>
          <div style={{ fontSize: 11, color: T.green, fontWeight: 700, marginBottom: 10, fontFamily: font.mono, letterSpacing: "0.08em", display: "flex", alignItems: "center", gap: 6 }}>
            <GlowDot color={T.green} size={6} /> ACTIVE POSITIONS
          </div>
          {active.map(s => <SignalCard key={s.signal_id} signal={s} isVip={isVip} />)}
        </div>
      )}

      <div>
        <div style={{ fontSize: 11, color: T.muted, fontWeight: 700, marginBottom: 10, fontFamily: font.mono, letterSpacing: "0.08em" }}>RECENT SIGNALS</div>
        {closed.map(s => <SignalCard key={s.signal_id} signal={s} isVip={isVip} />)}
      </div>
    </div>
  );
}

function PerformancePage({ stats, equity, dailyPnl }) {
  return (
    <div>
      <h1 style={{ fontSize: 22, fontWeight: 800, margin: "0 0 4px", fontFamily: font.display }}>Performance</h1>
      <p style={{ fontSize: 12, color: T.muted, margin: "0 0 20px", fontFamily: font.body }}>Live trading performance from Quant Agent engine</p>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))", gap: 10, marginBottom: 24 }}>
        <StatCard icon="🎯" label="Win Rate" value={`${stats.win_rate_pct}%`} color={stats.win_rate_pct >= 50 ? T.green : T.red} sub={`${stats.winners}W / ${stats.losers}L`} />
        <StatCard icon="💰" label="Total P&L" value={`$${stats.total_pnl_usd.toLocaleString()}`} color={stats.total_pnl_usd >= 0 ? T.green : T.red} />
        <StatCard icon="⚡" label="Profit Factor" value={stats.profit_factor.toFixed(2)} color={T.accent} />
        <StatCard icon="📉" label="Max Drawdown" value={`$${stats.max_drawdown_usd}`} color={T.yellow} />
        <StatCard icon="📊" label="Sharpe Ratio" value={stats.sharpe.toFixed(2)} color={T.purple} />
        <StatCard icon="⏱" label="Avg Hold" value={`${stats.avg_hold_min}m`} color={T.textSec} sub="per trade" />
      </div>

      <div style={{ background: T.card, borderRadius: 14, border: `1px solid ${T.border}`, padding: "20px 20px 12px", marginBottom: 16 }}>
        <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 14, fontFamily: font.display, color: T.text }}>Equity Curve</div>
        <ResponsiveContainer width="100%" height={260}>
          <AreaChart data={equity}>
            <defs>
              <linearGradient id="eqGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={T.accent} stopOpacity={0.25} />
                <stop offset="100%" stopColor={T.accent} stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke={T.border} />
            <XAxis dataKey="date" tick={{ fontSize: 10, fill: T.muted, fontFamily: font.mono }} axisLine={{ stroke: T.border }} tickLine={false} />
            <YAxis tick={{ fontSize: 10, fill: T.muted, fontFamily: font.mono }} axisLine={false} tickLine={false} domain={["auto", "auto"]} />
            <Tooltip content={<CustomTooltip />} />
            <Area type="monotone" dataKey="equity" stroke={T.accent} fill="url(#eqGrad)" strokeWidth={2} dot={false} />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      <div style={{ background: T.card, borderRadius: 14, border: `1px solid ${T.border}`, padding: "20px 20px 12px", marginBottom: 16 }}>
        <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 14, fontFamily: font.display, color: T.text }}>Daily P&L</div>
        <ResponsiveContainer width="100%" height={180}>
          <BarChart data={dailyPnl}>
            <CartesianGrid strokeDasharray="3 3" stroke={T.border} />
            <XAxis dataKey="date" tick={{ fontSize: 9, fill: T.muted, fontFamily: font.mono }} axisLine={{ stroke: T.border }} tickLine={false} />
            <YAxis tick={{ fontSize: 10, fill: T.muted, fontFamily: font.mono }} axisLine={false} tickLine={false} />
            <Tooltip content={<CustomTooltip />} />
            <Bar dataKey="pnl" radius={[3, 3, 0, 0]}>
              {dailyPnl.map((d, i) => (<Cell key={i} fill={d.pnl >= 0 ? T.green : T.red} opacity={0.8} />))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
        <div style={{ background: T.card, borderRadius: 14, border: `1px solid ${T.border}`, padding: 18 }}>
          <div style={{ fontSize: 11, color: T.muted, fontFamily: font.body, marginBottom: 4 }}>Best Trade</div>
          <div style={{ fontSize: 22, fontWeight: 800, color: T.green, fontFamily: font.mono }}>+${stats.best_trade}</div>
        </div>
        <div style={{ background: T.card, borderRadius: 14, border: `1px solid ${T.border}`, padding: 18 }}>
          <div style={{ fontSize: 11, color: T.muted, fontFamily: font.body, marginBottom: 4 }}>Worst Trade</div>
          <div style={{ fontSize: 22, fontWeight: 800, color: T.red, fontFamily: font.mono }}>${stats.worst_trade}</div>
        </div>
      </div>
    </div>
  );
}

function AdminPage({ signals, stats }) {
  const [cancelId, setCancelId] = useState(null);

  const handleCancel = async (signalId) => {
    setCancelId(signalId);
    if (USE_API) {
      try {
        await api.adminCancel(signalId, "admin-key-change-me");
      } catch (e) { console.error("Cancel failed:", e); }
    }
    setTimeout(() => setCancelId(null), 2000);
  };

  return (
    <div>
      <h1 style={{ fontSize: 22, fontWeight: 800, margin: "0 0 4px", fontFamily: font.display }}>Admin Panel</h1>
      <p style={{ fontSize: 12, color: T.muted, margin: "0 0 20px", fontFamily: font.body }}>Engine control & user management</p>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 10, marginBottom: 24 }}>
        <div style={{ background: T.card, borderRadius: 14, border: `1px solid ${T.green}44`, padding: 18 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
            <GlowDot color={T.green} />
            <span style={{ fontSize: 12, fontWeight: 700, fontFamily: font.body, color: T.text }}>Engine Status</span>
          </div>
          <div style={{ fontSize: 22, fontWeight: 800, color: T.green, fontFamily: font.mono }}>HEALTHY</div>
          <div style={{ fontSize: 11, color: T.muted, marginTop: 4, fontFamily: font.body }}>Last signal: 12 min ago</div>
        </div>
        <StatCard icon="👥" label="Users" value="156" sub="42 VIP • 5 Admin" color={T.accent} />
        <StatCard icon="💳" label="MRR" value="฿41,958" sub="42 × ฿999" color={T.green} />
        <StatCard icon="📡" label="Signals Today" value="3" sub={`${stats.active_signals} active`} color={T.yellow} />
      </div>

      {/* Active Signals Override */}
      <div style={{ background: T.card, borderRadius: 14, border: `1px solid ${T.border}`, padding: 20, marginBottom: 16 }}>
        <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 14, fontFamily: font.display, color: T.text }}>Active Signals — Emergency Override</div>
        {signals.filter(s => s.status === "ACTIVE").map(s => (
          <div key={s.signal_id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "12px 16px", background: T.surface, borderRadius: 10, marginBottom: 6 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <span style={{ fontWeight: 800, fontFamily: font.mono, fontSize: 14, color: T.text }}>{s.asset}</span>
              <Badge color={s.side === "LONG" ? T.green : T.red}>{s.side}</Badge>
              <span style={{ fontSize: 11, color: T.muted, fontFamily: font.mono }}>{s.signal_id}</span>
            </div>
            <button onClick={(e) => { e.stopPropagation(); handleCancel(s.signal_id); }} style={{
              background: cancelId === s.signal_id ? T.yellow : T.red, color: "#fff", border: "none",
              padding: "7px 18px", borderRadius: 8, cursor: "pointer", fontWeight: 700, fontSize: 11,
              fontFamily: font.mono, transition: "all 0.2s",
            }}>{cancelId === s.signal_id ? "⏳ Cancelling..." : "🚨 CANCEL"}</button>
          </div>
        ))}
        {signals.filter(s => s.status === "ACTIVE").length === 0 && (
          <div style={{ textAlign: "center", padding: 24, color: T.muted, fontSize: 13 }}>No active signals</div>
        )}
      </div>

      {/* Users Table */}
      <div style={{ background: T.card, borderRadius: 14, border: `1px solid ${T.border}`, padding: 20 }}>
        <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 14, fontFamily: font.display, color: T.text }}>User Management</div>
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr>
                {["User", "Role", "LINE", "TG", "Trades", "VIP Expires"].map(h => (
                  <th key={h} style={{ textAlign: "left", padding: "10px 12px", color: T.muted, fontWeight: 600, fontSize: 10, fontFamily: font.mono, letterSpacing: "0.06em", borderBottom: `1px solid ${T.border}`, textTransform: "uppercase" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {MOCK_USERS.map((u, i) => (
                <tr key={i} style={{ borderBottom: `1px solid ${T.border}08` }}>
                  <td style={{ padding: "10px 12px", fontWeight: 700, fontSize: 13, fontFamily: font.body, color: T.text }}>{u.name}</td>
                  <td style={{ padding: "10px 12px" }}>
                    <Badge color={u.role === "VIP" ? T.green : u.role === "ADMIN" ? T.purple : T.muted}>{u.role}</Badge>
                  </td>
                  <td style={{ padding: "10px 12px", fontSize: 12 }}>{u.line ? "✅" : "—"}</td>
                  <td style={{ padding: "10px 12px", fontSize: 12 }}>{u.tg ? "✅" : "—"}</td>
                  <td style={{ padding: "10px 12px", fontFamily: font.mono, fontSize: 12, color: T.textSec }}>{u.trades}</td>
                  <td style={{ padding: "10px 12px", fontFamily: font.mono, fontSize: 11, color: T.muted }}>{u.expires || "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// MAIN APP
// ═══════════════════════════════════════════════════════════

export default function App() {
  const [page, setPage] = useState("signals");
  const [isVip, setIsVip] = useState(true);
  const [signals, setSignals] = useState(MOCK_SIGNALS);
  const [stats, setStats] = useState(MOCK_STATS);
  const [equity, setEquity] = useState(MOCK_EQUITY);
  const [now, setNow] = useState(new Date());

  const dailyPnl = useMemo(() => equity.map(d => ({ date: d.date, pnl: d.pnl })), [equity]);

  // ── Clock
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  // ── API fetch (when USE_API = true)
  useEffect(() => {
    if (!USE_API) return;
    const load = async () => {
      try {
        const [sigRes, perfRes] = await Promise.all([
          api.getSignals(20), api.getPerformance(),
        ]);
        setSignals(sigRes.signals || []);
        setStats(prev => ({ ...prev, ...perfRes }));
        if (perfRes.equity_curve?.length) setEquity(perfRes.equity_curve);
      } catch (e) { console.error("API fetch error:", e); }
    };
    load();
    const interval = setInterval(load, 30000);  // refresh ทุก 30 วินาที
    return () => clearInterval(interval);
  }, []);

  const navItems = [
    { id: "signals",     label: "Signals",     icon: "⚡" },
    { id: "performance", label: "Performance",  icon: "📊" },
    { id: "admin",       label: "Admin",        icon: "⚙️" },
  ];

  return (
    <div style={{ background: T.bg, minHeight: "100vh", color: T.text, fontFamily: font.body }}>
      {/* Navbar */}
      <nav style={{
        background: T.card + "ee", backdropFilter: "blur(12px)",
        borderBottom: `1px solid ${T.border}`, padding: "0 20px",
        display: "flex", alignItems: "center", justifyContent: "space-between",
        height: 54, position: "sticky", top: 0, zIndex: 100,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 20 }}>
          <div style={{ fontSize: 16, fontWeight: 800, fontFamily: font.display, background: "linear-gradient(135deg, #2d7aff, #a855f7)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", letterSpacing: "-0.02em" }}>QUANT AGENT</div>
          <div style={{ width: 1, height: 24, background: T.border }} />
          <div style={{ display: "flex", gap: 2 }}>
            {navItems.map(n => (
              <button key={n.id} onClick={() => setPage(n.id)} style={{
                background: page === n.id ? T.accent + "18" : "transparent",
                color: page === n.id ? T.accent : T.muted,
                border: page === n.id ? `1px solid ${T.accent}30` : "1px solid transparent",
                padding: "6px 14px", borderRadius: 8, cursor: "pointer",
                fontSize: 12, fontWeight: 600, fontFamily: font.body,
                transition: "all 0.15s ease", display: "flex", alignItems: "center", gap: 4,
              }}><span style={{ fontSize: 13 }}>{n.icon}</span>{n.label}</button>
            ))}
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          {USE_API && <Badge color={T.green}>API LIVE</Badge>}
          {!USE_API && <Badge color={T.yellow}>MOCK DATA</Badge>}
          <span style={{ fontSize: 11, color: T.muted, fontFamily: font.mono }}>{now.toLocaleTimeString("en-US", { hour12: false })}</span>
          <button onClick={() => setIsVip(v => !v)} style={{
            background: isVip ? T.green + "18" : T.surface, color: isVip ? T.green : T.muted,
            border: `1px solid ${isVip ? T.green + "40" : T.border}`,
            padding: "5px 14px", borderRadius: 20, cursor: "pointer",
            fontSize: 11, fontWeight: 700, fontFamily: font.mono, transition: "all 0.2s",
          }}>{isVip ? "👑 VIP" : "👤 GUEST"}</button>
        </div>
      </nav>

      {/* Content */}
      <div style={{ maxWidth: 1100, margin: "0 auto", padding: "20px 16px 60px" }}>
        {page === "signals" && <SignalsPage signals={signals} isVip={isVip} />}
        {page === "performance" && <PerformancePage stats={stats} equity={equity} dailyPnl={dailyPnl} />}
        {page === "admin" && <AdminPage signals={signals} stats={stats} />}
      </div>

      {/* Footer */}
      <div style={{ borderTop: `1px solid ${T.border}`, padding: "14px 20px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <span style={{ fontSize: 11, color: T.muted, fontFamily: font.body }}>Quant Agent — 15m News Trading System</span>
        <div style={{ display: "flex", gap: 12 }}>
          <span style={{ fontSize: 10, color: T.muted, fontFamily: font.mono }}>Mode: {USE_API ? "API" : "Mock"}</span>
          <span style={{ fontSize: 10, color: T.muted, fontFamily: font.mono }}>v1.0.0</span>
        </div>
      </div>

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800&family=DM+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;600;700;800&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        @keyframes glow-pulse { 0%, 100% { opacity: 1; transform: scale(1); } 50% { opacity: 0.4; transform: scale(1.5); } }
        ::-webkit-scrollbar { width: 5px; }
        ::-webkit-scrollbar-track { background: ${T.bg}; }
        ::-webkit-scrollbar-thumb { background: ${T.border}; border-radius: 3px; }
        button:hover { filter: brightness(1.15); }
        button:active { transform: scale(0.98); }
      `}</style>
    </div>
  );
}
