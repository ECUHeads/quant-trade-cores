#!/usr/bin/env python3
"""
telegram_setup.py
==================
Interactive Telegram Bot Setup & Test Tool

วิธีใช้:
  python platform/telegram_setup.py

ทำอะไร:
  1. ตรวจ TELEGRAM_BOT_TOKEN ใน .env
  2. ทดสอบ connection กับ Telegram API
  3. ดึง bot info (ชื่อ, username)
  4. ช่วยหา chat_id ของ channel/group
  5. ทดสอบส่งข้อความ
  6. ตั้ง webhook (ถ้าต้องการ)
"""

import os
import sys
import json
import requests
from pathlib import Path
from datetime import datetime, timezone

# ── Load .env
try:
    from dotenv import load_dotenv
    # หา .env จาก project root
    env_paths = [
        Path(__file__).parent.parent / ".env",  # /opt/ttp-trading/.env
        Path(".env"),
    ]
    for p in env_paths:
        if p.exists():
            load_dotenv(p)
            break
except ImportError:
    pass


# ═══════════════════════════════════════════════════════════
# CONFIG
# ═══════════════════════════════════════════════════════════

BOT_TOKEN      = os.getenv("TELEGRAM_BOT_TOKEN", "")
VIP_CHAT_ID    = os.getenv("TELEGRAM_VIP_CHAT_ID", "")
PUBLIC_CHAT_ID = os.getenv("TELEGRAM_PUBLIC_CHAT_ID", "")
API_BASE_URL   = os.getenv("DASHBOARD_URL", "http://localhost:8000")

# Colors
G = "\033[92m"   # Green
R = "\033[91m"   # Red
Y = "\033[93m"   # Yellow
B = "\033[94m"   # Blue
W = "\033[97m"   # White
D = "\033[0m"    # Reset


def api_url(method: str) -> str:
    return f"https://api.telegram.org/bot{BOT_TOKEN}/{method}"


def api_call(method: str, data: dict = None) -> dict:
    """เรียก Telegram Bot API"""
    try:
        if data:
            resp = requests.post(api_url(method), json=data, timeout=15)
        else:
            resp = requests.get(api_url(method), timeout=15)
        return resp.json()
    except Exception as e:
        return {"ok": False, "description": str(e)}


# ═══════════════════════════════════════════════════════════
# STEP 1: CHECK TOKEN
# ═══════════════════════════════════════════════════════════

def step1_check_token():
    print(f"\n{B}{'='*55}{D}")
    print(f"{B}  Step 1: ตรวจ Bot Token{D}")
    print(f"{B}{'='*55}{D}\n")

    if not BOT_TOKEN:
        print(f"{R}❌ TELEGRAM_BOT_TOKEN ไม่พบใน .env{D}\n")
        print(f"{Y}วิธีสร้าง Bot:{D}")
        print(f"  1. เปิด Telegram → ค้นหา {W}@BotFather{D}")
        print(f"  2. พิมพ์ {W}/newbot{D}")
        print(f"  3. ตั้งชื่อ เช่น {W}Quant Agent Signal{D}")
        print(f"  4. ตั้ง username เช่น {W}quant_agent_signal_bot{D}")
        print(f"  5. คัดลอก token → ใส่ใน .env:")
        print(f"\n  {W}TELEGRAM_BOT_TOKEN=1234567890:ABCdefGHIjklMNOpqrsTUVwxyz{D}")
        print(f"\n  แล้วรันสคริปต์นี้อีกครั้ง")
        return False

    # ── Test connection
    print(f"  Token: {BOT_TOKEN[:10]}...{BOT_TOKEN[-5:]}")
    print(f"  กำลังเชื่อมต่อ Telegram API...")

    result = api_call("getMe")

    if result.get("ok"):
        bot = result["result"]
        print(f"\n  {G}✅ เชื่อมต่อสำเร็จ!{D}")
        print(f"  Bot Name:     {W}{bot.get('first_name', 'N/A')}{D}")
        print(f"  Bot Username: {W}@{bot.get('username', 'N/A')}{D}")
        print(f"  Bot ID:       {W}{bot.get('id', 'N/A')}{D}")
        print(f"  Can Join Groups: {W}{bot.get('can_join_groups', False)}{D}")
        return True
    else:
        print(f"\n  {R}❌ เชื่อมต่อไม่สำเร็จ:{D}")
        print(f"  {result.get('description', 'Unknown error')}")
        return False


# ═══════════════════════════════════════════════════════════
# STEP 2: FIND CHAT IDs
# ═══════════════════════════════════════════════════════════

def step2_find_chat_ids():
    print(f"\n{B}{'='*55}{D}")
    print(f"{B}  Step 2: หา Chat IDs{D}")
    print(f"{B}{'='*55}{D}\n")

    print(f"{Y}วิธีหา Chat ID ของ Channel/Group:{D}")
    print(f"  1. เพิ่ม bot เข้า channel/group เป็น admin")
    print(f"  2. ส่งข้อความอะไรก็ได้ใน channel/group นั้น")
    print(f"  3. กด Enter ที่นี่ เพื่อดึง updates\n")

    input(f"  {W}กด Enter เมื่อพร้อม...{D}")

    result = api_call("getUpdates", {"offset": -10, "limit": 10})

    if not result.get("ok"):
        print(f"\n  {R}❌ ดึง updates ไม่ได้: {result.get('description')}{D}")
        return

    updates = result.get("result", [])
    if not updates:
        print(f"\n  {Y}⚠️ ไม่พบ updates{D}")
        print(f"  → ลองส่งข้อความหา bot โดยตรง หรือ")
        print(f"  → ส่งข้อความใน channel ที่ bot เป็น admin")
        print(f"  → แล้วกด Enter อีกครั้ง\n")
        input(f"  {W}กด Enter เพื่อลองอีกครั้ง...{D}")
        result = api_call("getUpdates", {"offset": -10, "limit": 10})
        updates = result.get("result", [])

    if not updates:
        print(f"\n  {R}❌ ยังไม่พบ updates — ตรวจสอบว่า bot เป็น admin ใน channel{D}")
        return

    # ── แสดง chat IDs ที่เจอ
    seen_chats = {}
    for update in updates:
        msg = update.get("message") or update.get("channel_post") or {}
        chat = msg.get("chat", {})
        chat_id = str(chat.get("id", ""))
        if chat_id and chat_id not in seen_chats:
            seen_chats[chat_id] = {
                "type": chat.get("type", "unknown"),
                "title": chat.get("title") or chat.get("first_name") or "N/A",
                "username": chat.get("username", ""),
            }

    if seen_chats:
        print(f"\n  {G}พบ {len(seen_chats)} chat(s):{D}\n")
        for cid, info in seen_chats.items():
            icon = {"private": "👤", "group": "👥", "supergroup": "👥", "channel": "📢"}.get(info["type"], "❓")
            print(f"  {icon}  {W}{info['title']}{D}")
            print(f"     Type:    {info['type']}")
            print(f"     Chat ID: {G}{cid}{D}")
            if info["username"]:
                print(f"     @{info['username']}")
            print()

        print(f"{Y}คัดลอก Chat ID ไปใส่ .env:{D}")
        print(f"  TELEGRAM_VIP_CHAT_ID={G}<chat_id ของ VIP channel>{D}")
        print(f"  TELEGRAM_PUBLIC_CHAT_ID={G}<chat_id ของ Public channel>{D}")
    else:
        print(f"\n  {Y}⚠️ พบ updates แต่ไม่มี chat info{D}")


# ═══════════════════════════════════════════════════════════
# STEP 3: TEST SEND
# ═══════════════════════════════════════════════════════════

def step3_test_send():
    print(f"\n{B}{'='*55}{D}")
    print(f"{B}  Step 3: ทดสอบส่งข้อความ{D}")
    print(f"{B}{'='*55}{D}\n")

    # ── Check chat IDs
    targets = []
    if VIP_CHAT_ID:
        targets.append(("VIP Channel", VIP_CHAT_ID))
    if PUBLIC_CHAT_ID:
        targets.append(("Public Channel", PUBLIC_CHAT_ID))

    if not targets:
        chat_id = input(f"  {W}ใส่ Chat ID ที่ต้องการทดสอบ: {D}").strip()
        if chat_id:
            targets.append(("Manual Test", chat_id))
        else:
            print(f"  {Y}ข้าม — ไม่มี Chat ID{D}")
            return

    for name, chat_id in targets:
        print(f"\n  📤 ส่งไป {name} (ID: {chat_id})...")

        test_msg = (
            f"🧪 <b>Quant Agent — Test Message</b>\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"✅ Bot เชื่อมต่อสำเร็จ!\n"
            f"📅 {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"ข้อความนี้ยืนยันว่า bot สามารถส่งข้อความมาที่นี่ได้"
        )

        result = api_call("sendMessage", {
            "chat_id": chat_id,
            "text": test_msg,
            "parse_mode": "HTML",
        })

        if result.get("ok"):
            print(f"  {G}✅ ส่งสำเร็จ!{D}")
        else:
            print(f"  {R}❌ ส่งไม่สำเร็จ: {result.get('description')}{D}")
            if "chat not found" in result.get("description", "").lower():
                print(f"  → ตรวจว่า bot เป็น admin ใน channel/group นี้")
            elif "bot was blocked" in result.get("description", "").lower():
                print(f"  → User บล็อก bot — ต้อง unblock ก่อน")


# ═══════════════════════════════════════════════════════════
# STEP 4: TEST SIGNAL MESSAGE
# ═══════════════════════════════════════════════════════════

def step4_test_signal():
    print(f"\n{B}{'='*55}{D}")
    print(f"{B}  Step 4: ทดสอบส่งสัญญาณจำลอง{D}")
    print(f"{B}{'='*55}{D}\n")

    chat_id = VIP_CHAT_ID or PUBLIC_CHAT_ID
    if not chat_id:
        chat_id = input(f"  {W}ใส่ Chat ID: {D}").strip()
    if not chat_id:
        print(f"  {Y}ข้าม{D}")
        return

    # ── Import notifier
    try:
        sys.path.insert(0, str(Path(__file__).parent.parent))
        from platform.notifier_telegram import build_signal_html, build_cancel_html, build_daily_digest
    except ImportError:
        # Fallback: import from same dir
        try:
            from notifier_telegram import build_signal_html, build_cancel_html, build_daily_digest
        except ImportError:
            print(f"  {R}❌ ไม่สามารถ import notifier_telegram ได้{D}")
            return

    test_signal = {
        "signal_id": "SIG-TEST-001",
        "asset": "NVDA", "action": "BUY", "side": "LONG",
        "pricing_zone": {
            "entry_range": [182.00, 182.50],
            "take_profit": 187.75, "stop_loss": 179.56, "risk_reward": "1:2.5",
        },
        "strategy_type": "Trend Following",
        "news_catalyst": "NVDA beats Q2 EPS by 15%, raises guidance",
        "llm_cio_comment": "Strong earnings catalyst aligned with VWAP pullback. Low VIX environment favorable.",
        "ml_score": 76, "confidence": 0.81,
    }

    # ── Signal (VIP)
    print(f"  📤 Sending VIP signal card...")
    vip_html = build_signal_html(test_signal, is_vip=True)
    result = api_call("sendMessage", {
        "chat_id": chat_id, "text": vip_html,
        "parse_mode": "HTML", "disable_web_page_preview": True,
    })
    print(f"  {G}✅ VIP Signal sent{D}" if result.get("ok") else f"  {R}❌ {result.get('description')}{D}")

    # ── Cancel
    print(f"  📤 Sending cancel alert...")
    cancel_html = build_cancel_html(test_signal)
    result = api_call("sendMessage", {
        "chat_id": chat_id, "text": cancel_html,
        "parse_mode": "HTML",
    })
    print(f"  {G}✅ Cancel alert sent{D}" if result.get("ok") else f"  {R}❌ {result.get('description')}{D}")

    # ── Daily Digest
    print(f"  📤 Sending daily digest...")
    digest_html = build_daily_digest({
        "win_rate": 63.8, "total_pnl": 842.50,
        "total_trades": 47, "max_dd": 125.30,
    })
    result = api_call("sendMessage", {
        "chat_id": chat_id, "text": digest_html,
        "parse_mode": "HTML", "disable_web_page_preview": True,
    })
    print(f"  {G}✅ Daily digest sent{D}" if result.get("ok") else f"  {R}❌ {result.get('description')}{D}")


# ═══════════════════════════════════════════════════════════
# STEP 5: WEBHOOK SETUP (Optional)
# ═══════════════════════════════════════════════════════════

def step5_webhook():
    print(f"\n{B}{'='*55}{D}")
    print(f"{B}  Step 5: Webhook Setup (Optional){D}")
    print(f"{B}{'='*55}{D}\n")

    # ── Check current webhook
    result = api_call("getWebhookInfo")
    if result.get("ok"):
        info = result["result"]
        current_url = info.get("url", "")
        if current_url:
            print(f"  Current webhook: {W}{current_url}{D}")
            print(f"  Pending updates: {info.get('pending_update_count', 0)}")
            if info.get("last_error_message"):
                print(f"  Last error: {R}{info['last_error_message']}{D}")
        else:
            print(f"  Webhook: {Y}Not set (using polling){D}")

    print(f"\n{Y}Webhook คืออะไร?{D}")
    print(f"  Telegram จะส่ง update มาที่ server ของเรา (push)")
    print(f"  แทนที่ bot จะต้องไป getUpdates เอง (poll)")
    print(f"  → ต้องมี HTTPS domain ที่เข้าถึงได้จาก internet\n")

    answer = input(f"  {W}ตั้ง webhook? (y/N): {D}").strip().lower()
    if answer != "y":
        print(f"  {Y}ข้าม — ใช้ polling mode{D}")
        return

    domain = input(f"  {W}Domain (เช่น signal.yourdomain.com): {D}").strip()
    if not domain:
        print(f"  {Y}ข้าม{D}")
        return

    webhook_url = f"https://{domain}/webhook/telegram"
    print(f"\n  Setting webhook → {W}{webhook_url}{D}")

    result = api_call("setWebhook", {
        "url": webhook_url,
        "allowed_updates": ["message", "channel_post"],
        "drop_pending_updates": True,
    })

    if result.get("ok"):
        print(f"  {G}✅ Webhook ตั้งสำเร็จ!{D}")
        print(f"  Telegram จะส่ง POST ไปที่: {webhook_url}")
    else:
        print(f"  {R}❌ {result.get('description')}{D}")


# ═══════════════════════════════════════════════════════════
# STEP 6: SUMMARY
# ═══════════════════════════════════════════════════════════

def step6_summary():
    print(f"\n{B}{'='*55}{D}")
    print(f"{B}  Summary — .env Settings{D}")
    print(f"{B}{'='*55}{D}\n")

    checks = [
        ("TELEGRAM_BOT_TOKEN", BOT_TOKEN, True),
        ("TELEGRAM_VIP_CHAT_ID", VIP_CHAT_ID, True),
        ("TELEGRAM_PUBLIC_CHAT_ID", PUBLIC_CHAT_ID, False),
        ("DASHBOARD_URL", API_BASE_URL, False),
    ]

    all_ok = True
    for name, val, required in checks:
        if val and val not in ("", "https://your-dashboard.com"):
            status = f"{G}✅{D}"
        elif required:
            status = f"{R}❌{D}"
            all_ok = False
        else:
            status = f"{Y}⚠️ (optional){D}"

        display_val = f"{val[:20]}..." if len(val) > 20 else val or "(not set)"
        print(f"  {status} {name}={display_val}")

    print()
    if all_ok:
        print(f"  {G}✅ Telegram bot พร้อมใช้งาน!{D}")
    else:
        print(f"  {R}⚠️ ยังตั้งค่าไม่ครบ — ดูคำแนะนำด้านบน{D}")

    print(f"\n{Y}Next steps:{D}")
    print(f"  1. ตรวจ .env ว่าครบ")
    print(f"  2. Start API: uvicorn platform.signal_api:app --port 8000")
    print(f"  3. เมื่อ engine ส่ง signal → จะ notify อัตโนมัติ")
    print(f"  4. (Optional) ตั้ง webhook สำหรับรับ /start, /status commands")
    print()


# ═══════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════

def main():
    print(f"\n{W}{'═'*55}{D}")
    print(f"{W}  🤖 Quant Agent — Telegram Bot Setup{D}")
    print(f"{W}{'═'*55}{D}")
    print(f"  เครื่องมือช่วย setup Telegram bot ทีละขั้น\n")

    # Step 1: Token
    if not step1_check_token():
        return

    # Step 2: Find Chat IDs
    step2_find_chat_ids()

    # Reload env (in case user edited .env during step 2)
    global VIP_CHAT_ID, PUBLIC_CHAT_ID
    VIP_CHAT_ID    = os.getenv("TELEGRAM_VIP_CHAT_ID", VIP_CHAT_ID)
    PUBLIC_CHAT_ID = os.getenv("TELEGRAM_PUBLIC_CHAT_ID", PUBLIC_CHAT_ID)

    # Step 3: Test basic send
    step3_test_send()

    # Step 4: Test signal format
    answer = input(f"\n  {W}ทดสอบส่งสัญญาณจำลอง? (Y/n): {D}").strip().lower()
    if answer != "n":
        step4_test_signal()

    # Step 5: Webhook (optional)
    step5_webhook()

    # Step 6: Summary
    step6_summary()


if __name__ == "__main__":
    main()
