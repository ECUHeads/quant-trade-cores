#!/usr/bin/env python3
"""
line_quick_test.py
===================
Quick test — ส่งข้อความทดสอบไป LINE ทันที

Usage:
  # ส่ง signal card ไปหา follower คนแรก
  python platform/line_quick_test.py

  # ส่งไป user_id เฉพาะ
  python platform/line_quick_test.py --user-id U1234567890abcdef

  # ส่ง cancel test
  python platform/line_quick_test.py --type cancel

  # ส่งทุกแบบ
  python platform/line_quick_test.py --type all

  # Broadcast ไปทุก follower
  python platform/line_quick_test.py --broadcast

  # Preview flex JSON (ไม่ส่งจริง → เอาไป paste ใน Flex Simulator)
  python platform/line_quick_test.py --preview
"""

import os
import sys
import json
import argparse
import requests
from pathlib import Path

# ── Load .env
try:
    from dotenv import load_dotenv
    for p in [Path(__file__).parent.parent / ".env", Path(".env")]:
        if p.exists():
            load_dotenv(p); break
except ImportError:
    pass

# ── Import notifier
sys.path.insert(0, str(Path(__file__).parent.parent))
try:
    from platform.notifier_line import (
        build_signal_flex, build_cancel_flex, send_signal_flex,
        send_cancel_message, send_daily_summary, LINE_TOKEN,
    )
except ImportError:
    from notifier_line import (
        build_signal_flex, build_cancel_flex, send_signal_flex,
        send_cancel_message, send_daily_summary, LINE_TOKEN,
    )


LINE_API_BASE = "https://api.line.me/v2/bot"

TEST_SIGNAL = {
    "signal_id": "SIG-TEST-001",
    "asset": "NVDA", "action": "BUY", "side": "LONG",
    "pricing_zone": {
        "entry_range": [182.00, 182.50],
        "take_profit": 187.75, "stop_loss": 179.56, "risk_reward": "1:2.5",
    },
    "strategy_type": "Trend Following",
    "news_catalyst": "NVDA beats Q2 EPS by 15%, raises guidance",
    "llm_cio_comment": "Strong earnings catalyst aligned with VWAP pullback. Low VIX. Sector confirmed.",
    "ml_score": 76, "confidence": 0.81,
}

TEST_STATS = {
    "win_rate": 63.8, "total_pnl": 842.50,
    "total_trades": 47, "max_dd": 125.30,
}


def get_first_follower() -> str:
    """ดึง user_id ของ follower คนแรก"""
    headers = {
        "Authorization": f"Bearer {LINE_TOKEN}",
    }
    try:
        resp = requests.get(f"{LINE_API_BASE}/followers/ids", headers=headers, timeout=10)
        if resp.status_code == 200:
            ids = resp.json().get("userIds", [])
            return ids[0] if ids else ""
    except Exception:
        pass
    return ""


def broadcast_message(messages: list) -> bool:
    """Broadcast ไปทุก follower"""
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {LINE_TOKEN}",
    }
    payload = {"messages": messages}
    try:
        resp = requests.post(
            f"{LINE_API_BASE}/message/broadcast",
            json=payload, headers=headers, timeout=15,
        )
        return resp.status_code == 200
    except Exception:
        return False


def main():
    parser = argparse.ArgumentParser(description="LINE Quick Test")
    parser.add_argument("--user-id", help="Target LINE user ID (U...)")
    parser.add_argument("--type", choices=["signal", "cancel", "summary", "all"],
                        default="signal", help="Message type")
    parser.add_argument("--broadcast", action="store_true",
                        help="Broadcast to all followers")
    parser.add_argument("--preview", action="store_true",
                        help="Preview Flex JSON only (no send)")
    args = parser.parse_args()

    if not LINE_TOKEN:
        print("❌ LINE_CHANNEL_ACCESS_TOKEN ไม่พบใน .env")
        sys.exit(1)

    # ── Preview mode
    if args.preview:
        print("📋 Flex Message JSON (Signal Card):")
        print("=" * 50)
        flex = build_signal_flex(TEST_SIGNAL)
        print(json.dumps(flex, indent=2, ensure_ascii=False))
        print("\n" + "=" * 50)
        print("📋 Flex Message JSON (Cancel):")
        print("=" * 50)
        cancel = build_cancel_flex(TEST_SIGNAL)
        print(json.dumps(cancel, indent=2, ensure_ascii=False))
        print("\n✅ คัดลอก JSON ไปวางใน LINE Flex Message Simulator:")
        print("   https://developers.line.biz/flex-simulator/")
        return

    # ── Resolve target
    user_id = args.user_id
    if not user_id and not args.broadcast:
        print("🔍 กำลังหา follower คนแรก...")
        user_id = get_first_follower()
        if user_id:
            print(f"   พบ: {user_id[:20]}...")
        else:
            print("❌ ไม่พบ follower — ใช้ --user-id หรือเพิ่มเพื่อน bot ก่อน")
            sys.exit(1)

    print(f"🤖 Token: {LINE_TOKEN[:15]}...{LINE_TOKEN[-5:]}")
    if args.broadcast:
        print(f"📤 Mode:  BROADCAST (ทุก follower)")
    else:
        print(f"📤 Target: {user_id[:20]}...")
    print(f"📋 Type:   {args.type}")
    print()

    types = [args.type] if args.type != "all" else ["signal", "cancel", "summary"]

    for t in types:
        if t == "signal":
            print("📡 Sending signal Flex Message...")
            if args.broadcast:
                flex = build_signal_flex(TEST_SIGNAL)
                ok = broadcast_message([flex])
            else:
                ok = send_signal_flex(user_id, TEST_SIGNAL)
            print(f"   {'✅ Sent!' if ok else '❌ Failed'}")

        elif t == "cancel":
            print("⚠️  Sending cancel alert...")
            if args.broadcast:
                cancel = build_cancel_flex(TEST_SIGNAL)
                ok = broadcast_message([cancel])
            else:
                ok = send_cancel_message(user_id, TEST_SIGNAL)
            print(f"   {'✅ Sent!' if ok else '❌ Failed'}")

        elif t == "summary":
            print("📊 Sending daily summary...")
            if args.broadcast:
                ok = broadcast_message([{
                    "type": "text",
                    "text": "📊 สรุปวันนี้\nWin Rate: 63.8%\nP&L: $+842.50\nTrades: 47",
                }])
            else:
                ok = send_daily_summary(user_id, TEST_STATS)
            print(f"   {'✅ Sent!' if ok else '❌ Failed'}")

    print("\n✅ Done! ตรวจ LINE ว่าได้รับข้อความ")


if __name__ == "__main__":
    main()
