#!/usr/bin/env python3
"""
line_setup.py
==============
Interactive LINE Messaging API Setup & Test Tool

วิธีใช้:
  python platform/line_setup.py

ทำอะไร:
  1. ตรวจ LINE_CHANNEL_ACCESS_TOKEN ใน .env
  2. ทดสอบ connection กับ LINE API
  3. ดึง bot info (ชื่อ, รูป)
  4. ดึง follower count
  5. ทดสอบส่ง Flex Message
  6. สร้าง Rich Menu
  7. ตั้ง Webhook URL
"""

import os
import sys
import json
import requests
from pathlib import Path
from datetime import datetime, timezone

# ── Load .env
try:
    from dotenv import load_dotenv
    for p in [Path(__file__).parent.parent / ".env", Path(".env")]:
        if p.exists():
            load_dotenv(p); break
except ImportError:
    pass

# ── Import notifier
sys.path.insert(0, str(Path(__file__).parent.parent))
try:
    from platform.notifier_line import (
        build_signal_flex, build_cancel_flex, LINE_TOKEN, DASHBOARD_URL,
    )
except ImportError:
    try:
        from notifier_line import (
            build_signal_flex, build_cancel_flex, LINE_TOKEN, DASHBOARD_URL,
        )
    except ImportError:
        LINE_TOKEN = os.getenv("LINE_CHANNEL_ACCESS_TOKEN", "")
        DASHBOARD_URL = os.getenv("DASHBOARD_URL", "https://your-dashboard.com")
        build_signal_flex = None
        build_cancel_flex = None


# ═══════════════════════════════════════════════════════════
# CONFIG
# ═══════════════════════════════════════════════════════════

LINE_API_BASE = "https://api.line.me/v2/bot"
LINE_API_DATA = "https://api-data.line.me/v2/bot"  # for binary uploads

# Colors
G = "\033[92m"
R = "\033[91m"
Y = "\033[93m"
B = "\033[94m"
W = "\033[97m"
D = "\033[0m"


def headers():
    return {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {LINE_TOKEN}",
    }


def api_get(path: str) -> dict:
    try:
        resp = requests.get(f"{LINE_API_BASE}{path}", headers=headers(), timeout=15)
        if resp.status_code == 200:
            return {"ok": True, "data": resp.json()}
        return {"ok": False, "status": resp.status_code, "error": resp.text[:300]}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def api_post(path: str, data: dict, base: str = LINE_API_BASE) -> dict:
    try:
        resp = requests.post(f"{base}{path}", json=data, headers=headers(), timeout=15)
        if resp.status_code == 200:
            return {"ok": True, "data": resp.json() if resp.text else {}}
        return {"ok": False, "status": resp.status_code, "error": resp.text[:300]}
    except Exception as e:
        return {"ok": False, "error": str(e)}


# ═══════════════════════════════════════════════════════════
# STEP 1: CHECK TOKEN
# ═══════════════════════════════════════════════════════════

def step1_check_token():
    print(f"\n{B}{'='*55}{D}")
    print(f"{B}  Step 1: ตรวจ Channel Access Token{D}")
    print(f"{B}{'='*55}{D}\n")

    if not LINE_TOKEN:
        print(f"{R}❌ LINE_CHANNEL_ACCESS_TOKEN ไม่พบใน .env{D}\n")
        print(f"{Y}วิธีสร้าง LINE Messaging API Channel:{D}")
        print(f"  1. ไปที่ {W}https://developers.line.biz/console{D}")
        print(f"  2. Log in ด้วย LINE account")
        print(f"  3. Create a new Provider (ถ้ายังไม่มี)")
        print(f"  4. Create a {W}Messaging API{D} channel")
        print(f"  5. ตั้ง channel name: {W}Quant Agent Signal{D}")
        print(f"  6. ไปแท็บ {W}Messaging API{D}")
        print(f"  7. กด {W}Issue{D} ที่ Channel Access Token (long-lived)")
        print(f"  8. คัดลอก token → ใส่ใน .env:\n")
        print(f"  {W}LINE_CHANNEL_ACCESS_TOKEN=<long-lived token>{D}")
        print(f"\n  แล้วรันสคริปต์นี้อีกครั้ง")
        return False

    # ── Test connection
    print(f"  Token: {LINE_TOKEN[:15]}...{LINE_TOKEN[-5:]}")
    print(f"  กำลังเชื่อมต่อ LINE API...\n")

    result = api_get("/info")

    if result["ok"]:
        info = result["data"]
        print(f"  {G}✅ เชื่อมต่อสำเร็จ!{D}")
        print(f"  Bot Name:    {W}{info.get('displayName', 'N/A')}{D}")
        print(f"  Bot ID:      {W}{info.get('userId', 'N/A')}{D}")
        print(f"  Picture URL: {info.get('pictureUrl', 'N/A')[:60]}")
        print(f"  Chat Mode:   {info.get('chatMode', 'N/A')}")
        print(f"  Mark as Read: {info.get('markAsReadMode', 'N/A')}")
        return True
    else:
        print(f"  {R}❌ เชื่อมต่อไม่สำเร็จ:{D}")
        print(f"  Status: {result.get('status', 'N/A')}")
        print(f"  Error: {result.get('error', 'Unknown')}")
        if result.get("status") == 401:
            print(f"\n  {Y}→ Token ผิดหรือหมดอายุ ลอง Issue ใหม่ที่ LINE Console{D}")
        return False


# ═══════════════════════════════════════════════════════════
# STEP 2: CHECK FOLLOWERS
# ═══════════════════════════════════════════════════════════

def step2_check_followers():
    print(f"\n{B}{'='*55}{D}")
    print(f"{B}  Step 2: ตรวจ Followers{D}")
    print(f"{B}{'='*55}{D}\n")

    result = api_get("/followers/ids")

    if result["ok"]:
        data = result["data"]
        user_ids = data.get("userIds", [])
        print(f"  {G}พบ {len(user_ids)} follower(s){D}\n")

        for uid in user_ids[:10]:
            # ดึง profile แต่ละคน
            profile = api_get(f"/profile/{uid}")
            if profile["ok"]:
                name = profile["data"].get("displayName", "Unknown")
                print(f"  👤 {W}{name}{D}")
                print(f"     User ID: {uid[:20]}...")
            else:
                print(f"  👤 User ID: {uid[:20]}...")
            print()

        if not user_ids:
            print(f"  {Y}⚠️ ยังไม่มี follower{D}")
            print(f"  → เพิ่มเพื่อน bot ด้วย QR Code หรือ link จาก LINE Console")
            print(f"  → ไปที่ Messaging API → Bot Information → QR Code")

        return user_ids
    else:
        print(f"  {Y}⚠️ ดึง followers ไม่ได้ (อาจต้อง upgrade plan){D}")
        print(f"  {Y}   Free plan ไม่มี Followers API{D}")
        print(f"  {Y}   แต่ push message ยังใช้ได้ถ้ามี user_id{D}")
        return []


# ═══════════════════════════════════════════════════════════
# STEP 3: TEST SEND MESSAGE
# ═══════════════════════════════════════════════════════════

def step3_test_send(user_ids: list):
    print(f"\n{B}{'='*55}{D}")
    print(f"{B}  Step 3: ทดสอบส่งข้อความ{D}")
    print(f"{B}{'='*55}{D}\n")

    # ── Pick target
    target_id = ""
    if user_ids:
        target_id = user_ids[0]
        print(f"  จะส่งไปหา follower คนแรก: {target_id[:20]}...")
    else:
        target_id = input(f"  {W}ใส่ LINE User ID (U...): {D}").strip()

    if not target_id:
        print(f"  {Y}ข้าม — ไม่มี User ID{D}")
        print(f"  → เพิ่มเพื่อน bot ก่อน แล้วลองใหม่")
        return

    # ── Test text message
    print(f"\n  📤 ส่งข้อความทดสอบ...")
    payload = {
        "to": target_id,
        "messages": [{
            "type": "text",
            "text": f"🧪 Quant Agent — ทดสอบการเชื่อมต่อ\n✅ Bot ส่งข้อความได้สำเร็จ!\n📅 {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}",
        }],
    }

    result = api_post("/message/push", payload)
    if result["ok"]:
        print(f"  {G}✅ ส่งข้อความสำเร็จ!{D}")
    else:
        print(f"  {R}❌ ส่งไม่สำเร็จ:{D}")
        print(f"  {result.get('error', 'Unknown')}")
        if "not found" in result.get("error", "").lower():
            print(f"  → User ยังไม่ได้เพิ่มเพื่อน bot")
        return

    return target_id


# ═══════════════════════════════════════════════════════════
# STEP 4: TEST FLEX MESSAGE
# ═══════════════════════════════════════════════════════════

def step4_test_flex(target_id: str):
    print(f"\n{B}{'='*55}{D}")
    print(f"{B}  Step 4: ทดสอบ Flex Message (การ์ดสัญญาณ){D}")
    print(f"{B}{'='*55}{D}\n")

    if not target_id:
        print(f"  {Y}ข้าม — ไม่มี User ID{D}")
        return

    if not build_signal_flex:
        print(f"  {R}❌ ไม่สามารถ import notifier_line ได้{D}")
        return

    test_signal = {
        "signal_id": "SIG-TEST-001",
        "asset": "NVDA", "action": "BUY", "side": "LONG",
        "pricing_zone": {
            "entry_range": [182.00, 182.50],
            "take_profit": 187.75, "stop_loss": 179.56, "risk_reward": "1:2.5",
        },
        "strategy_type": "Trend Following",
        "news_catalyst": "NVDA beats Q2 EPS by 15%, raises guidance",
        "llm_cio_comment": "Strong earnings catalyst aligned with VWAP pullback. Low VIX environment favorable.",
        "ml_score": 76, "confidence": 0.81,
    }

    # ── Signal Card
    print(f"  📤 ส่ง Signal Flex Message...")
    flex = build_signal_flex(test_signal)
    payload = {"to": target_id, "messages": [flex]}

    result = api_post("/message/push", payload)
    if result["ok"]:
        print(f"  {G}✅ Signal card ส่งสำเร็จ! ดูใน LINE{D}")
    else:
        print(f"  {R}❌ {result.get('error', 'Unknown')}{D}")

    # ── Cancel Card
    print(f"  📤 ส่ง Cancel Alert...")
    cancel_flex = build_cancel_flex(test_signal)
    payload = {"to": target_id, "messages": [cancel_flex]}

    result = api_post("/message/push", payload)
    if result["ok"]:
        print(f"  {G}✅ Cancel alert ส่งสำเร็จ!{D}")
    else:
        print(f"  {R}❌ {result.get('error', 'Unknown')}{D}")

    # ── Daily Summary
    print(f"  📤 ส่ง Daily Summary...")
    payload = {
        "to": target_id,
        "messages": [{
            "type": "text",
            "text": "📊 สรุปวันนี้\nWin Rate: 63.8%\nP&L: $+842.50\nTrades: 47",
        }],
    }
    result = api_post("/message/push", payload)
    if result["ok"]:
        print(f"  {G}✅ Daily summary ส่งสำเร็จ!{D}")
    else:
        print(f"  {R}❌ {result.get('error', 'Unknown')}{D}")


# ═══════════════════════════════════════════════════════════
# STEP 5: WEBHOOK SETUP
# ═══════════════════════════════════════════════════════════

def step5_webhook():
    print(f"\n{B}{'='*55}{D}")
    print(f"{B}  Step 5: Webhook Setup{D}")
    print(f"{B}{'='*55}{D}\n")

    # ── Check current webhook
    result = api_get("/channel/webhook/endpoint")
    if result["ok"]:
        current = result["data"].get("endpoint", "")
        active = result["data"].get("active", False)
        print(f"  Current: {W}{current or '(not set)'}{D}")
        print(f"  Active:  {G if active else Y}{'✅ Yes' if active else '❌ No'}{D}")
    else:
        print(f"  {Y}ไม่สามารถดึง webhook info ได้{D}")

    print(f"\n{Y}Webhook ทำให้ bot รับ events ได้:{D}")
    print(f"  • User เพิ่มเพื่อน (follow) → auto register")
    print(f"  • User ส่งข้อความ → ตอบกลับอัตโนมัติ")
    print(f"  • User block/unblock → อัพเดต status\n")

    answer = input(f"  {W}ตั้ง webhook? (y/N): {D}").strip().lower()
    if answer != "y":
        print(f"  {Y}ข้าม{D}")
        print(f"\n  {Y}ตั้ง webhook ภายหลังได้ที่:{D}")
        print(f"  LINE Console → Messaging API → Webhook settings")
        print(f"  Webhook URL: https://signal.yourdomain.com/webhook/line")
        return

    domain = input(f"  {W}Domain (เช่น signal.yourdomain.com): {D}").strip()
    if not domain:
        print(f"  {Y}ข้าม{D}")
        return

    webhook_url = f"https://{domain}/webhook/line"
    print(f"\n  Setting webhook → {W}{webhook_url}{D}")

    result = api_post("/channel/webhook/endpoint", {"endpoint": webhook_url})

    if result["ok"]:
        print(f"  {G}✅ Webhook URL ตั้งสำเร็จ!{D}")

        # ── Test webhook
        print(f"  📤 ทดสอบ webhook...")
        test_result = api_post("/channel/webhook/test", {"endpoint": webhook_url})
        if test_result["ok"]:
            success = test_result["data"].get("success", False)
            print(f"  {'✅ Webhook ใช้งานได้!' if success else '❌ Webhook test failed'}")
            if not success:
                print(f"  → ตรวจว่า server รันอยู่ + SSL valid + endpoint ตอบ 200")
        else:
            print(f"  {Y}⚠️ ทดสอบไม่ได้ — ต้องตรวจ manually{D}")
    else:
        print(f"  {R}❌ {result.get('error', 'Unknown')}{D}")
        print(f"\n  {Y}→ ตั้ง webhook ผ่าน LINE Console แทน:{D}")
        print(f"  Messaging API → Webhook settings → {webhook_url}")


# ═══════════════════════════════════════════════════════════
# STEP 6: RICH MENU (Optional)
# ═══════════════════════════════════════════════════════════

def step6_rich_menu():
    print(f"\n{B}{'='*55}{D}")
    print(f"{B}  Step 6: Rich Menu (Optional){D}")
    print(f"{B}{'='*55}{D}\n")

    print(f"{Y}Rich Menu คือแถบเมนูด้านล่างหน้าจอ LINE:{D}")
    print(f"  ┌─────────┬─────────┬─────────┐")
    print(f"  │  📊     │  👑     │  📞     │")
    print(f"  │ สถิติ   │ VIP    │ ติดต่อ  │")
    print(f"  └─────────┴─────────┴─────────┘\n")

    answer = input(f"  {W}สร้าง Rich Menu? (y/N): {D}").strip().lower()
    if answer != "y":
        print(f"  {Y}ข้าม — สร้างภายหลังได้{D}")
        return

    # ── Create Rich Menu
    menu_data = {
        "size": {"width": 2500, "height": 843},
        "selected": True,
        "name": "Quant Agent Menu",
        "chatBarText": "📊 เมนู",
        "areas": [
            {
                "bounds": {"x": 0, "y": 0, "width": 833, "height": 843},
                "action": {"type": "message", "text": "📊 สถิติเดือนนี้"},
            },
            {
                "bounds": {"x": 833, "y": 0, "width": 834, "height": 843},
                "action": {"type": "message", "text": "👑 สถานะ VIP ของฉัน"},
            },
            {
                "bounds": {"x": 1667, "y": 0, "width": 833, "height": 843},
                "action": {
                    "type": "uri",
                    "uri": DASHBOARD_URL,
                    "label": "📋 Dashboard",
                },
            },
        ],
    }

    result = api_post("/richmenu", menu_data)
    if result["ok"]:
        menu_id = result["data"].get("richMenuId", "")
        print(f"  {G}✅ Rich Menu สร้างสำเร็จ!{D}")
        print(f"  Menu ID: {W}{menu_id}{D}")
        print(f"\n  {Y}ขั้นตอนถัดไป:{D}")
        print(f"  1. อัพโหลดรูป Rich Menu (2500x843 px) ผ่าน LINE Console")
        print(f"     หรือใช้ API: POST /v2/bot/richmenu/{'{menu_id}'}/content")
        print(f"  2. ตั้งเป็น default:")
        print(f"     POST /v2/bot/user/all/richmenu/{menu_id}")

        # ── Set as default
        set_answer = input(f"\n  {W}ตั้งเป็น default rich menu? (y/N): {D}").strip().lower()
        if set_answer == "y":
            set_result = api_post(f"/user/all/richmenu/{menu_id}", {})
            if set_result["ok"]:
                print(f"  {G}✅ ตั้ง default สำเร็จ!{D}")
                print(f"  {Y}⚠️ ยังต้องอัพโหลดรูปเมนูก่อนจึงจะแสดง{D}")
            else:
                print(f"  {R}❌ {set_result.get('error')}{D}")
    else:
        print(f"  {R}❌ {result.get('error', 'Unknown')}{D}")


# ═══════════════════════════════════════════════════════════
# STEP 7: SUMMARY
# ═══════════════════════════════════════════════════════════

def step7_summary():
    print(f"\n{B}{'='*55}{D}")
    print(f"{B}  Summary — .env Settings{D}")
    print(f"{B}{'='*55}{D}\n")

    checks = [
        ("LINE_CHANNEL_ACCESS_TOKEN", LINE_TOKEN, True),
        ("DASHBOARD_URL", DASHBOARD_URL, False),
    ]

    for name, val, required in checks:
        if val and val not in ("", "https://your-dashboard.com"):
            status = f"{G}✅{D}"
        elif required:
            status = f"{R}❌{D}"
        else:
            status = f"{Y}⚠️ (optional){D}"
        display_val = f"{val[:25]}..." if len(val) > 25 else val or "(not set)"
        print(f"  {status} {name}={display_val}")

    print(f"\n{Y}วิธีที่ LINE ทำงานในระบบ:{D}")
    print(f"  1. User เพิ่มเพื่อน bot → webhook /webhook/line → register user")
    print(f"  2. Engine สร้าง signal → _notify_all() → send_signal_flex()")
    print(f"  3. Admin cancel → _notify_cancel() → send_cancel_message()")
    print(f"  4. Bot ส่ง push message เฉพาะ VIP users\n")

    print(f"{Y}LINE pricing (Free plan):{D}")
    print(f"  • Push message: 200 ข้อความ/เดือน (ฟรี)")
    print(f"  • เกิน 200: ฿0.075/ข้อความ")
    print(f"  • Light plan (฿0): 500 ข้อความ/เดือน")
    print(f"  • Standard plan (฿800): 15,000 ข้อความ/เดือน\n")

    print(f"{Y}Next steps:{D}")
    print(f"  1. ตรวจ .env ว่ามี LINE_CHANNEL_ACCESS_TOKEN")
    print(f"  2. ตั้ง Webhook URL ที่ LINE Console")
    print(f"     → Messaging API → Webhook: https://domain/webhook/line")
    print(f"  3. ปิด Auto-reply ที่ LINE Console")
    print(f"     → Messaging API → Auto-reply messages → Disabled")
    print(f"  4. Start API: uvicorn platform.signal_api:app --port 8000")
    print(f"  5. เมื่อ engine ส่ง signal → LINE notify อัตโนมัติ")
    print()


# ═══════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════

def main():
    print(f"\n{W}{'═'*55}{D}")
    print(f"{W}  💚 Quant Agent — LINE Bot Setup{D}")
    print(f"{W}{'═'*55}{D}")
    print(f"  เครื่องมือช่วย setup LINE Messaging API ทีละขั้น\n")

    # Step 1
    if not step1_check_token():
        return

    # Step 2
    user_ids = step2_check_followers()

    # Step 3
    target_id = step3_test_send(user_ids)

    # Step 4
    if target_id:
        answer = input(f"\n  {W}ทดสอบ Flex Message (การ์ดสวย)? (Y/n): {D}").strip().lower()
        if answer != "n":
            step4_test_flex(target_id)

    # Step 5
    step5_webhook()

    # Step 6
    step6_rich_menu()

    # Step 7
    step7_summary()


if __name__ == "__main__":
    main()
