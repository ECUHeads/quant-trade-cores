"""
platform/dashboard_routes.py
=============================
FastAPI — Static File Serving for Dashboard

เพิ่ม routes เข้า signal_api.py เพื่อ serve React dashboard
จาก platform/static/ directory (Vite build output)

Usage:
  1. cd platform/frontend && npm run build   → output ไป platform/static/
  2. uvicorn platform.signal_api:app         → serve ทั้ง API + Dashboard

Architecture:
  ┌──────────────────────────────────────┐
  │         FastAPI (port 8000)          │
  │                                      │
  │  /api/*     → Signal API endpoints   │
  │  /admin/*   → Admin endpoints        │
  │  /webhook/* → LINE/TG webhooks       │
  │  /assets/*  → Static JS/CSS (Vite)   │
  │  /*         → index.html (SPA)       │
  └──────────────────────────────────────┘
"""

import os
from pathlib import Path
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, HTMLResponse


# ── Path to Vite build output
STATIC_DIR = Path(__file__).parent / "static"


def mount_dashboard(app: FastAPI):
    """
    Mount dashboard static files ลง FastAPI app

    เรียกหลัง app ถูกสร้าง แต่ก่อน uvicorn.run()

    ตัวอย่าง:
        from platform.dashboard_routes import mount_dashboard
        mount_dashboard(app)
    """

    if not STATIC_DIR.exists():
        import logging
        logging.getLogger("Dashboard").warning(
            f"⚠️  Static dir not found: {STATIC_DIR}\n"
            f"   Run: cd platform/frontend && npm install && npm run build"
        )
        return

    index_html = STATIC_DIR / "index.html"

    # ── Mount /assets/ for Vite hashed bundles (JS, CSS, images)
    assets_dir = STATIC_DIR / "assets"
    if assets_dir.exists():
        app.mount(
            "/assets",
            StaticFiles(directory=str(assets_dir)),
            name="static-assets",
        )

    # ── Serve other static files (favicon, robots.txt, etc.)
    for f in STATIC_DIR.iterdir():
        if f.is_file() and f.name != "index.html":
            # สร้าง route สำหรับแต่ละ static file ที่ root
            file_path = str(f)
            route_path = f"/{f.name}"

            # ต้อง capture file_path ใน closure
            def make_handler(fp):
                async def handler():
                    return FileResponse(fp)
                return handler

            app.get(route_path, include_in_schema=False)(make_handler(file_path))

    # ── SPA Catch-All: ทุก path ที่ไม่ match API → serve index.html
    # ต้องอยู่หลัง API routes ทั้งหมด
    @app.get("/{full_path:path}", include_in_schema=False)
    async def serve_spa(full_path: str):
        """
        SPA Catch-All Route

        ทุก path ที่ไม่ใช่ /api/, /admin/, /webhook/
        จะ serve index.html เพื่อให้ React Router จัดการ

        Nginx production จะ handle ส่วนนี้แทน
        """
        # ถ้า request path ตรงกับ file ใน static → serve file นั้น
        requested = STATIC_DIR / full_path
        if requested.is_file() and STATIC_DIR in requested.resolve().parents:
            return FileResponse(str(requested))

        # ไม่งั้น → serve index.html (SPA routing)
        if index_html.exists():
            return FileResponse(str(index_html))

        return HTMLResponse(
            "<h1>Dashboard not built</h1>"
            "<p>Run: <code>cd platform/frontend && npm install && npm run build</code></p>",
            status_code=404,
        )
