#!/usr/bin/env python3
"""
telegram_quick_test.py
=======================
Quick test — ส่ง signal ทดสอบไป Telegram ทันที (ไม่ต้อง interactive)

Usage:
  # ส่งไป VIP channel
  python platform/telegram_quick_test.py

  # ส่งไป chat_id เฉพาะ
  python platform/telegram_quick_test.py --chat-id -100123456789

  # ส่ง cancel test
  python platform/telegram_quick_test.py --type cancel

  # ส่ง daily digest test
  python platform/telegram_quick_test.py --type digest

  # ส่งทุกแบบ
  python platform/telegram_quick_test.py --type all
"""

import os
import sys
import argparse
from pathlib import Path

# ── Load .env
try:
    from dotenv import load_dotenv
    for p in [Path(__file__).parent.parent / ".env", Path(".env")]:
        if p.exists():
            load_dotenv(p); break
except ImportError:
    pass

# ── Import notifier
sys.path.insert(0, str(Path(__file__).parent.parent))
try:
    from platform.notifier_telegram import (
        send_signal_telegram, send_cancel_telegram,
        build_signal_html, build_cancel_html, build_daily_digest,
        _send_message, TG_BOT_TOKEN, TG_VIP_CHAT_ID, TG_PUBLIC_CHAT_ID,
    )
except ImportError:
    from notifier_telegram import (
        send_signal_telegram, send_cancel_telegram,
        build_signal_html, build_cancel_html, build_daily_digest,
        _send_message, TG_BOT_TOKEN, TG_VIP_CHAT_ID, TG_PUBLIC_CHAT_ID,
    )


TEST_SIGNAL = {
    "signal_id": "SIG-TEST-001",
    "asset": "NVDA", "action": "BUY", "side": "LONG",
    "pricing_zone": {
        "entry_range": [182.00, 182.50],
        "take_profit": 187.75, "stop_loss": 179.56, "risk_reward": "1:2.5",
    },
    "strategy_type": "Trend Following",
    "news_catalyst": "NVDA beats Q2 EPS by 15%, raises guidance",
    "llm_cio_comment": "Strong earnings catalyst aligned with VWAP pullback. Low VIX. Sector confirmed by SMH breakout.",
    "ml_score": 76, "confidence": 0.81,
    "gate19_action": "EXECUTE",
}

TEST_STATS = {
    "win_rate": 63.8, "total_pnl": 842.50,
    "total_trades": 47, "max_dd": 125.30,
}


def main():
    parser = argparse.ArgumentParser(description="Telegram Quick Test")
    parser.add_argument("--chat-id", help="Target chat ID (default: VIP channel)")
    parser.add_argument("--type", choices=["signal", "cancel", "digest", "all"],
                        default="signal", help="Message type to send")
    args = parser.parse_args()

    # ── Resolve chat ID
    chat_id = args.chat_id or TG_VIP_CHAT_ID or TG_PUBLIC_CHAT_ID
    if not chat_id:
        print("❌ ไม่มี chat_id — ใส่ --chat-id หรือตั้ง TELEGRAM_VIP_CHAT_ID ใน .env")
        sys.exit(1)

    if not TG_BOT_TOKEN:
        print("❌ TELEGRAM_BOT_TOKEN ไม่พบใน .env")
        sys.exit(1)

    print(f"🤖 Bot Token: {TG_BOT_TOKEN[:10]}...{TG_BOT_TOKEN[-5:]}")
    print(f"📤 Target:    {chat_id}")
    print(f"📋 Type:      {args.type}")
    print()

    types = [args.type] if args.type != "all" else ["signal", "cancel", "digest"]

    for t in types:
        if t == "signal":
            print("📡 Sending VIP signal...")
            ok = send_signal_telegram(chat_id, TEST_SIGNAL, is_vip=True)
            print(f"   {'✅ Sent!' if ok else '❌ Failed'}")

        elif t == "cancel":
            print("⚠️  Sending cancel alert...")
            ok = send_cancel_telegram(chat_id, TEST_SIGNAL)
            print(f"   {'✅ Sent!' if ok else '❌ Failed'}")

        elif t == "digest":
            print("📊 Sending daily digest...")
            html = build_daily_digest(TEST_STATS)
            ok = _send_message(chat_id, html)
            print(f"   {'✅ Sent!' if ok else '❌ Failed'}")

    print("\n✅ Done! ตรวจ Telegram ว่าได้รับข้อความ")


if __name__ == "__main__":
    main()
