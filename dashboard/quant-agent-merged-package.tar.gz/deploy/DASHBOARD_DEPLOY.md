# Dashboard Deployment Guide
## Quant Agent — Signal Dashboard + API

---

## Architecture

```
┌─────────────────────────────────────────────────┐
│              Nginx (port 80/443)                │
│                                                  │
│  /assets/*     → static files (Vite build)      │
│  /index.html   → SPA entry (React dashboard)    │
│  /api/*        → proxy → FastAPI :8000          │
│  /admin/*      → proxy → FastAPI :8000          │
│  /webhook/*    → proxy → FastAPI :8000          │
└─────────────────┬───────────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────────────┐
│          FastAPI / uvicorn (port 8000)           │
│                                                  │
│  signal_api.py     → API endpoints              │
│  dashboard_routes  → serve static (fallback)    │
│  models.py         → SQLAlchemy ORM             │
│  signals.db        → SQLite database            │
└─────────────────────────────────────────────────┘
```

**Development**: FastAPI serve ทั้ง API + Dashboard (port 8000)
**Production**: Nginx serve static files + proxy API → FastAPI

---

## Quick Start (Development)

```bash
# 1. Build dashboard
cd platform/frontend
npm install
npm run build          # → output ไป platform/static/

# 2. Patch signal_api.py (เพิ่ม dashboard serving)
#    เพิ่มบรรทัดนี้ก่อน `if __name__` block:
#
#    from platform.dashboard_routes import mount_dashboard
#    mount_dashboard(app)

# 3. Start server
cd /opt/ttp-trading
uvicorn platform.signal_api:app --host 0.0.0.0 --port 8000 --reload

# 4. Open browser
#    http://localhost:8000
```

---

## Development Mode (Hot Reload)

สำหรับ frontend development — ใช้ Vite dev server แยก:

```bash
# Terminal 1: FastAPI (API only)
uvicorn platform.signal_api:app --host 0.0.0.0 --port 8000 --reload

# Terminal 2: Vite dev server (dashboard + proxy API)
cd platform/frontend
npm run dev
# → http://localhost:3000  (API proxy → :8000)
```

Vite dev server จะ proxy `/api/*` ไป FastAPI อัตโนมัติ

---

## Production Deployment

### 1. Build Frontend

```bash
./deploy/build_frontend.sh --install
```

### 2. Patch signal_api.py

เพิ่มที่ท้าย signal_api.py (ก่อน `if __name__`):

```python
# ── Dashboard (Static Files)
from platform.dashboard_routes import mount_dashboard
mount_dashboard(app)
```

### 3. Install Nginx Config

```bash
sudo cp deploy/nginx-quant-agent.conf /etc/nginx/sites-available/quant-agent
sudo ln -s /etc/nginx/sites-available/quant-agent /etc/nginx/sites-enabled/

# แก้ domain ใน config
sudo nano /etc/nginx/sites-available/quant-agent
# → server_name signal.yourdomain.com;

sudo nginx -t && sudo systemctl reload nginx
```

### 4. SSL (Let's Encrypt)

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d signal.yourdomain.com
```

### 5. Start Services (PM2)

```bash
npm install -g pm2
pm2 start deploy/ecosystem.config.js
pm2 save && pm2 startup
```

### 6. Verify

```bash
# ตรวจสอบ services
pm2 status

# ตรวจ API
curl http://localhost:8000/api/health

# ตรวจ dashboard
curl -s http://localhost:8000 | head -5
```

---

## File Structure

```
platform/
├── frontend/                  ← Vite + React source
│   ├── package.json
│   ├── vite.config.js
│   ├── index.html
│   └── src/
│       ├── main.jsx
│       └── App.jsx            ← Dashboard component
│
├── static/                    ← Vite build output (git-ignored)
│   ├── index.html
│   └── assets/
│       ├── index-xxxxx.js
│       └── index-xxxxx.css
│
├── signal_api.py              ← FastAPI (API + static serve)
├── dashboard_routes.py        ← Static file serving module
├── models.py                  ← SQLAlchemy models
├── signal_bridge.py           ← JSON → API bridge
├── notifier_line.py           ← LINE notifications
└── notifier_telegram.py       ← Telegram notifications

deploy/
├── build_frontend.sh          ← Build script
├── ecosystem.config.js        ← PM2 config
├── nginx-quant-agent.conf     ← Nginx config
└── DASHBOARD_DEPLOY.md        ← This file
```

---

## Switching Mock → API

เมื่อ backend + DB พร้อม:

1. เปิดไฟล์ `platform/frontend/src/App.jsx`
2. เปลี่ยน `const USE_API = false;` → `const USE_API = true;`
3. Rebuild: `cd platform/frontend && npm run build`
4. Restart: `pm2 restart signal-api`

Dashboard จะ fetch ข้อมูลจาก:
- `GET /api/signals` → signals list
- `GET /api/performance` → stats + equity curve
- `GET /api/health` → engine status

Auto-refresh ทุก 30 วินาที

---

## Updating Dashboard

```bash
# 1. แก้ไข source
nano platform/frontend/src/App.jsx

# 2. Rebuild
./deploy/build_frontend.sh

# 3. Restart API (ถ้าใช้ FastAPI serve)
pm2 restart signal-api

# ถ้าใช้ Nginx serve static → ไม่ต้อง restart อะไร
# Nginx จะ serve file ใหม่ทันที (index.html มี no-cache)
```

---

## Troubleshooting

**Dashboard แสดง "Dashboard not built"**
→ ยังไม่ได้ build frontend:  `./deploy/build_frontend.sh --install`

**API fetch error ใน browser console**
→ ตรวจว่า FastAPI รันอยู่:  `pm2 status` หรือ `curl localhost:8000/api/health`

**Nginx 502 Bad Gateway**
→ FastAPI ยังไม่ start:  `pm2 restart signal-api`

**Vite dev server ไม่ proxy**
→ ตรวจว่า FastAPI รันที่ port 8000:  `lsof -i :8000`

**Fonts ไม่โหลด**
→ ตรวจ internet connection — Google Fonts ต้องเข้าถึงได้
