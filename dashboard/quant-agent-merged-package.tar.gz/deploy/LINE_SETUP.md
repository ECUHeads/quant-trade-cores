# LINE Messaging API Setup Guide
## Quant Agent — Signal Distribution via LINE

---

## สิ่งที่จะได้

LINE Bot ส่งการ์ด Flex Message สวยงามแบบนี้:

```
┌─────────────────────────────────┐
│ 🟢 LONG (ซื้อ)          NVDA  │  ← Header สีเขียว
├─────────────────────────────────┤
│ 📍 Entry   $182.00 – $182.50  │
│ 🎯 TP      $187.75   (+3.1%) │  ← Pricing Zone
│ 🛡️ SL      $179.56   (-1.3%) │
│ ⚖️ R:R     1:2.5              │
├─────────────────────────────────┤
│ 🏄 กลยุทธ์: ตามน้ำ (Trend)     │
│ 📰 NVDA beats Q2 EPS by 15%  │  ← Catalyst
│ 🧠 ML Score: 76 | Conf: 81%  │
├─────────────────────────────────┤
│ 🤖 AI CIO Analysis:            │
│ "Strong catalyst aligned..."   │  ← VIP only
├─────────────────────────────────┤
│  [📊 ดูกราฟ]  [📋 Dashboard]   │  ← ปุ่มกด
└─────────────────────────────────┘
```

---

## Setup ทีละขั้น

### ขั้นที่ 1: สร้าง LINE Messaging API Channel

1. ไปที่ **https://developers.line.biz/console**
2. Login ด้วย LINE account (ใช้อันเดียวกับ LINE ในมือถือ)
3. กด **Create a new provider** (ถ้ายังไม่มี)
   - ชื่อ: `Quant Agent` หรือชื่อบริษัท
4. กด **Create a Messaging API channel**
   - Channel name: `Quant Agent Signal`
   - Channel description: `AI-powered stock signal bot`
   - Category: `Finance` → `Securities`
   - Email: อีเมลของคุณ
5. กด **Create**

### ขั้นที่ 2: Issue Channel Access Token

1. เข้า channel ที่สร้าง → แท็บ **Messaging API**
2. เลื่อนลงหา **Channel access token (long-lived)**
3. กด **Issue**
4. คัดลอก token → ใส่ใน `.env`:

```bash
LINE_CHANNEL_ACCESS_TOKEN=<long-lived token ที่ได้>
```

### ขั้นที่ 3: ตั้งค่า Channel Settings

ที่ LINE Console เดียวกัน:

#### 3a. ปิด Auto-reply (สำคัญ!)
- Messaging API → **Auto-reply messages** → กด **Edit**
- ระบบจะเปิด LINE Official Account Manager
- ไปที่ **Response settings**:
  - Response mode: **Bot**
  - Auto-response: **Disabled** ← สำคัญ!
  - Greeting message: **Disabled** (หรือใส่ข้อความต้อนรับ)

#### 3b. เปิด Webhook
- Messaging API → **Webhook settings**:
  - Use webhook: **Enabled**
  - Webhook URL: `https://signal.yourdomain.com/webhook/line`
  - (ตั้งทีหลังก็ได้ เมื่อ deploy แล้ว)

#### 3c. ดู QR Code
- Messaging API → **Bot information** → **QR code**
- ใช้ QR นี้แจกให้ user เพิ่มเพื่อน bot

### ขั้นที่ 4: เพิ่มเพื่อน Bot

1. เปิด LINE ในมือถือ
2. Scan QR Code จาก step 3c (หรือค้นหา @bot-username)
3. กด **เพิ่มเพื่อน**
4. ส่งข้อความอะไรก็ได้ (เพื่อให้ bot มี user_id ของเรา)

### ขั้นที่ 5: ทดสอบ

```bash
# ── Interactive setup (ตรวจทุกอย่างทีละขั้น)
python platform/line_setup.py

# ── Quick test ส่งสัญญาณจำลอง
python platform/line_quick_test.py

# ── ส่งทุกแบบ (signal + cancel + summary)
python platform/line_quick_test.py --type all

# ── ส่งไป user_id เฉพาะ
python platform/line_quick_test.py --user-id U1234567890abcdef

# ── Broadcast ไปทุก follower
python platform/line_quick_test.py --broadcast

# ── Preview Flex JSON (ไม่ส่งจริง → ใช้กับ Simulator)
python platform/line_quick_test.py --preview
```

### ขั้นที่ 6: Webhook (Production)

เมื่อ VPS + domain + SSL พร้อม:

1. **LINE Console** → Messaging API → Webhook settings
2. Webhook URL: `https://signal.yourdomain.com/webhook/line`
3. กด **Verify** → ต้องได้ **Success**

หรือใช้ setup script:
```bash
python platform/line_setup.py
# → Step 5 จะถามเรื่อง webhook
```

เมื่อ webhook ทำงาน:
- User เพิ่มเพื่อน → auto register เข้า database
- User block → สามารถ cleanup ได้

---

## Architecture

```
signal_api.py
  │
  ├── POST /api/signals (จาก Signal Bridge)
  │     └── _notify_all()
  │           └── for each VIP user with line_user_id:
  │                 send_signal_flex(user_id, signal)
  │                   → LINE Push API → Flex Message card
  │
  ├── POST /admin/cancel/{id}
  │     └── _notify_cancel()
  │           └── send_cancel_message() → ทุก VIP
  │
  └── POST /webhook/line (จาก LINE)
        ├── follow event → _register_line_user()
        └── message event → (future: handle commands)
```

**สำคัญ:** LINE ใช้ **Push Message** (1:1) ไม่มี "channel broadcast" แบบ Telegram
- ส่งทีละ user → ใช้ `send_signal_flex(user_id, signal)`
- `_notify_all()` จะ loop ส่งทุก VIP user ที่มี `line_user_id`
- Broadcast API (ส่งทุก follower) มีอยู่แต่ใช้ quota เยอะ

---

## ข้อความที่ bot ส่งได้

| ประเภท | Function | รูปแบบ | เมื่อไหร่ |
|---|---|---|---|
| Signal Card | `send_signal_flex()` | Flex Message (การ์ด) | มี signal ใหม่ |
| Cancel Alert | `send_cancel_message()` | Flex Message (เหลือง) | Admin cancel |
| Daily Summary | `send_daily_summary()` | Text message | ท้ายวัน |

---

## Flex Message Simulator

ทดสอบ Flex Message ก่อนส่งจริง:

1. ไปที่ **https://developers.line.biz/flex-simulator/**
2. รัน: `python platform/line_quick_test.py --preview`
3. คัดลอก JSON output → วางใน Simulator
4. จะเห็นหน้าตาการ์ดแบบที่ user จะเห็นจริง

---

## Rich Menu

Rich Menu คือแถบเมนูด้านล่าง chat:

```
┌─────────┬─────────┬─────────┐
│  📊     │  👑     │  📋     │
│ สถิติ   │ VIP    │Dashboard│
└─────────┴─────────┴─────────┘
```

### สร้าง Rich Menu

#### วิธี A: ใช้ setup script
```bash
python platform/line_setup.py
# → Step 6 จะถามเรื่อง Rich Menu
```

#### วิธี B: ใช้ LINE Official Account Manager (ง่ายกว่า)
1. ไปที่ https://manager.line.biz
2. เลือก account → Rich menus
3. Create → ออกแบบด้วย GUI
4. ใส่ actions: ข้อความ "📊 สถิติ" / URI ไป dashboard

---

## LINE Pricing

| Plan | ข้อความ/เดือน | ค่าใช้จ่าย |
|---|---|---|
| Free | 200 | ฟรี |
| Light | 500 | ฿0/เดือน |
| Standard | 15,000 | ฿800/เดือน |
| เกิน quota | ตาม plan | ฿0.075/ข้อความ |

**ตัวอย่างคำนวณ:**
- 42 VIP users × 3 signals/วัน × 22 วัน = 2,772 ข้อความ/เดือน
- Free plan (200) ไม่พอ → ใช้ Standard (15,000) = ฿800/เดือน
- หรือส่งเฉพาะ signal ที่สำคัญ → ลด message count

---

## .env Summary

```bash
# ── LINE (Required)
LINE_CHANNEL_ACCESS_TOKEN=<long-lived token>

# ── Dashboard URL (สำหรับปุ่มใน Flex Message)
DASHBOARD_URL=https://signal.yourdomain.com

# ── LINE Channel Secret (สำหรับ webhook signature verification)
# LINE_CHANNEL_SECRET=<channel secret>  # optional, เพิ่มภายหลัง
```

---

## Troubleshooting

| ปัญหา | สาเหตุ | แก้ไข |
|---|---|---|
| `LINE_CHANNEL_ACCESS_TOKEN not set` | ไม่ได้ใส่ token | Issue token ที่ LINE Console |
| `401 Unauthorized` | Token ผิดหรือหมดอายุ | Issue token ใหม่ |
| `400 Bad Request: user not found` | User ยังไม่ได้เพิ่มเพื่อน bot | ให้ user scan QR เพิ่มเพื่อน |
| `429 Too Many Requests` | ส่งเกิน rate limit | LINE limit: 100,000 req/min |
| Flex Message ไม่แสดง | JSON ผิด format | ใช้ Simulator ตรวจ JSON |
| Bot ตอบซ้ำ | Auto-reply ยังเปิดอยู่ | ปิดที่ LINE OA Manager |
| Webhook verify ไม่ผ่าน | SSL ไม่ valid / server ไม่ตอบ | ตรวจ HTTPS + endpoint ต้อง return 200 |
| Message quota หมด | เกินจำนวนตาม plan | Upgrade plan หรือลดจำนวน signal |
| ไม่ได้รับ follow event | Webhook ไม่ได้ตั้ง | ตั้ง webhook URL ที่ LINE Console |
| Rich Menu ไม่แสดง | ยังไม่ได้อัพโหลดรูป | อัพรูป 2500x843px ผ่าน LINE Console |
