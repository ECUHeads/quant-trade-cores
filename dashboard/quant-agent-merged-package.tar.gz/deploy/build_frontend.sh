#!/bin/bash
# ============================================================
# build_frontend.sh — Build & Deploy Dashboard
# ============================================================
#
# Usage:
#   ./deploy/build_frontend.sh              # build เฉย ๆ
#   ./deploy/build_frontend.sh --install    # npm install + build
#   ./deploy/build_frontend.sh --dev        # dev server (port 3000)
#
# Output:
#   platform/static/           ← Vite build output
#   ├── index.html
#   └── assets/
#       ├── index-xxxxx.js     ← hashed bundle
#       └── index-xxxxx.css
#
# ============================================================

set -euo pipefail

# ── Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# ── Paths
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
FRONTEND_DIR="$PROJECT_ROOT/platform/frontend"
STATIC_DIR="$PROJECT_ROOT/platform/static"

echo -e "${BLUE}═══════════════════════════════════════${NC}"
echo -e "${BLUE}  Quant Agent — Frontend Build${NC}"
echo -e "${BLUE}═══════════════════════════════════════${NC}"
echo ""

# ── Check Node.js
if ! command -v node &> /dev/null; then
    echo -e "${RED}❌ Node.js not found!${NC}"
    echo "   Install: curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash - && sudo apt install -y nodejs"
    exit 1
fi

NODE_VER=$(node --version)
echo -e "${GREEN}✓${NC} Node.js: $NODE_VER"

# ── Check npm
if ! command -v npm &> /dev/null; then
    echo -e "${RED}❌ npm not found!${NC}"
    exit 1
fi

NPM_VER=$(npm --version)
echo -e "${GREEN}✓${NC} npm: $NPM_VER"
echo ""

cd "$FRONTEND_DIR"

# ── Install dependencies
if [[ "${1:-}" == "--install" ]] || [[ ! -d "node_modules" ]]; then
    echo -e "${YELLOW}📦 Installing dependencies...${NC}"
    npm install --production=false
    echo -e "${GREEN}✓${NC} Dependencies installed"
    echo ""
fi

# ── Dev mode
if [[ "${1:-}" == "--dev" ]]; then
    echo -e "${YELLOW}🚀 Starting dev server on http://localhost:3000${NC}"
    echo -e "${YELLOW}   API proxy → http://localhost:8000${NC}"
    echo ""
    npm run dev
    exit 0
fi

# ── Build
echo -e "${YELLOW}🔨 Building dashboard...${NC}"
npm run build

# ── Verify output
if [[ -f "$STATIC_DIR/index.html" ]]; then
    echo ""
    echo -e "${GREEN}✅ Build successful!${NC}"
    echo ""

    # Show output files
    echo -e "${BLUE}Output files:${NC}"
    find "$STATIC_DIR" -type f | while read f; do
        SIZE=$(du -h "$f" | cut -f1)
        echo -e "  ${GREEN}✓${NC} ${f#$PROJECT_ROOT/}  (${SIZE})"
    done

    TOTAL=$(du -sh "$STATIC_DIR" | cut -f1)
    echo ""
    echo -e "${BLUE}Total size: ${TOTAL}${NC}"
    echo ""
    echo -e "${GREEN}Dashboard ready at: ${STATIC_DIR}${NC}"
    echo ""
    echo -e "Next steps:"
    echo -e "  1. Start API:  ${YELLOW}uvicorn platform.signal_api:app --host 0.0.0.0 --port 8000${NC}"
    echo -e "  2. Open:       ${YELLOW}http://localhost:8000${NC}"
    echo ""
else
    echo -e "${RED}❌ Build failed — index.html not found${NC}"
    exit 1
fi
