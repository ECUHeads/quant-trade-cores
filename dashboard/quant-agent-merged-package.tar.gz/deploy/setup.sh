#!/bin/bash
# deploy/setup.sh
# ===============
# One-command production setup script
#
# Usage:
#   chmod +x deploy/setup.sh
#   sudo ./deploy/setup.sh
#
# This script:
#   1. Creates user 'trader' (if not exists)
#   2. Creates log directory
#   3. Installs PM2 (if Node.js available) OR sets up systemd services
#   4. Sets up cron for log archival
#   5. Initializes Alembic (if not done)

set -e

PROJECT_DIR="/opt/ttp-trading"
LOG_DIR="${PROJECT_DIR}/logs"
USER="trader"

echo "═══════════════════════════════════════"
echo "  Quant Agent — Production Setup"
echo "═══════════════════════════════════════"

# ── 1. Create user
if ! id "$USER" &>/dev/null; then
    echo "[1/5] Creating user: $USER"
    useradd -r -m -s /bin/bash "$USER"
else
    echo "[1/5] User $USER already exists"
fi

# ── 2. Create directories
echo "[2/5] Creating directories"
mkdir -p "$LOG_DIR"
mkdir -p "${PROJECT_DIR}/signals/processed"
mkdir -p "${PROJECT_DIR}/signals/failed"
mkdir -p "${PROJECT_DIR}/journal"
mkdir -p "${PROJECT_DIR}/models"
mkdir -p "${PROJECT_DIR}/profiles"
chown -R "$USER:$USER" "$PROJECT_DIR"

# ── 3. Process Manager
echo "[3/5] Setting up process manager"
if command -v pm2 &>/dev/null; then
    echo "  PM2 found — using PM2"
    echo "  Run: pm2 start ecosystem.config.js"
    echo "  Then: pm2 save && pm2 startup"
elif command -v npm &>/dev/null; then
    echo "  Installing PM2..."
    npm install -g pm2
    echo "  Run: pm2 start ecosystem.config.js"
    echo "  Then: pm2 save && pm2 startup"
else
    echo "  PM2 not available — using systemd"
    cp "${PROJECT_DIR}/deploy/quant-engine.service" /etc/systemd/system/
    cp "${PROJECT_DIR}/deploy/signal-api.service" /etc/systemd/system/
    cp "${PROJECT_DIR}/deploy/signal-bridge.service" /etc/systemd/system/
    systemctl daemon-reload
    systemctl enable quant-engine signal-api signal-bridge
    echo "  systemd services installed"
    echo "  Start: sudo systemctl start quant-engine signal-api signal-bridge"
fi

# ── 4. Cron for log archival
echo "[4/5] Setting up log archival cron"
CRON_CMD="30 4 * * * ${PROJECT_DIR}/venv/bin/python3 ${PROJECT_DIR}/deploy/log_archiver.py --cleanup-gdrive >> ${LOG_DIR}/archiver.log 2>&1"
(crontab -u "$USER" -l 2>/dev/null || true; echo "$CRON_CMD") | sort -u | crontab -u "$USER" -
echo "  Cron installed: daily 04:30 log archival"

# ── 5. Alembic
echo "[5/5] Checking Alembic setup"
if [ ! -d "${PROJECT_DIR}/platform/migrations" ]; then
    echo "  Run: python deploy/init_alembic.py"
else
    echo "  Alembic migrations/ already exists"
fi

echo ""
echo "═══════════════════════════════════════"
echo "  ✅ Setup complete!"
echo ""
echo "  Next steps:"
echo "    1. Edit .env with your API keys"
echo "    2. Train models (Phase 1)"
echo "    3. Start services:"
echo "       PM2:     pm2 start ecosystem.config.js"
echo "       systemd: sudo systemctl start quant-engine signal-api signal-bridge"
echo "═══════════════════════════════════════"

# ── 6. Frontend Dashboard (Optional)
echo ""
echo "[6/8] Frontend Dashboard (optional)"
FRONTEND_DIR="${PROJECT_DIR}/platform/frontend"
STATIC_DIR="${PROJECT_DIR}/platform/static"

if [ -d "$FRONTEND_DIR" ] && [ -f "${FRONTEND_DIR}/package.json" ]; then
    if command -v node &>/dev/null && command -v npm &>/dev/null; then
        NODE_VER=$(node --version)
        echo "  Node.js found: $NODE_VER"
        echo "  Building dashboard..."
        cd "$FRONTEND_DIR"
        npm install --production=false 2>/dev/null
        npm run build 2>/dev/null
        cd "$PROJECT_DIR"
        if [ -f "${STATIC_DIR}/index.html" ]; then
            echo "  ✅ Dashboard built → ${STATIC_DIR}/"
            chown -R "$USER:$USER" "$STATIC_DIR"
        else
            echo "  ⚠️  Build failed — run manually: cd ${FRONTEND_DIR} && npm run build"
        fi
    else
        echo "  ⚠️  Node.js not found — skipping frontend build"
        echo "  Install: curl -fsSL https://deb.nodesource.com/setup_20.x | bash - && apt install -y nodejs"
        echo "  Then: cd ${FRONTEND_DIR} && npm install && npm run build"
    fi
else
    echo "  ⚠️  Frontend source not found at ${FRONTEND_DIR}"
    echo "  Dashboard will not be available until built"
fi

# ── 7. Nginx (Optional)
echo ""
echo "[7/8] Nginx reverse proxy (optional)"
NGINX_CONF="${PROJECT_DIR}/deploy/nginx-quant-agent.conf"

if [ -f "$NGINX_CONF" ]; then
    if command -v nginx &>/dev/null; then
        echo "  Nginx found"
        if [ ! -f "/etc/nginx/sites-available/quant-agent" ]; then
            echo "  To install Nginx config:"
            echo "    sudo cp ${NGINX_CONF} /etc/nginx/sites-available/quant-agent"
            echo "    sudo ln -s /etc/nginx/sites-available/quant-agent /etc/nginx/sites-enabled/"
            echo "    # Edit domain: sudo nano /etc/nginx/sites-available/quant-agent"
            echo "    sudo nginx -t && sudo systemctl reload nginx"
        else
            echo "  ✅ Nginx config already installed"
        fi
    else
        echo "  ⚠️  Nginx not installed — API will serve directly on :8000"
        echo "  Install: sudo apt install nginx"
    fi
else
    echo "  ⚠️  Nginx config not found at ${NGINX_CONF}"
fi

# ── 8. LINE + Telegram Bot Check
echo ""
echo "[8/8] Notification bots check"

# Check .env for bot tokens
ENV_FILE="${PROJECT_DIR}/.env"
if [ -f "$ENV_FILE" ]; then
    if grep -q "TELEGRAM_BOT_TOKEN=" "$ENV_FILE" && ! grep -q "TELEGRAM_BOT_TOKEN=$" "$ENV_FILE"; then
        echo "  ✅ Telegram bot token found"
    else
        echo "  ⚠️  TELEGRAM_BOT_TOKEN not set in .env"
        echo "    Setup: python platform/telegram_setup.py"
    fi

    if grep -q "LINE_CHANNEL_ACCESS_TOKEN=" "$ENV_FILE" && ! grep -q "LINE_CHANNEL_ACCESS_TOKEN=$" "$ENV_FILE"; then
        echo "  ✅ LINE token found"
    else
        echo "  ⚠️  LINE_CHANNEL_ACCESS_TOKEN not set in .env"
        echo "    Setup: python platform/line_setup.py"
    fi
else
    echo "  ⚠️  .env file not found — copy from .env.example"
fi

echo ""
echo "═══════════════════════════════════════"
echo "  ✅ Full setup complete!"
echo ""
echo "  Dashboard:  http://localhost:8000 (after frontend build)"
echo "  API Docs:   http://localhost:8000/docs"
echo "  Health:     http://localhost:8000/api/health"
echo "═══════════════════════════════════════"
