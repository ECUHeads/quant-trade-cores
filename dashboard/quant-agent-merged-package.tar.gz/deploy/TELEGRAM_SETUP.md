# Telegram Bot Setup Guide
## Quant Agent — Signal Distribution via Telegram

---

## สิ่งที่จะได้

```
Quant Engine (Gate 19 verdict)
  │
  ▼
Signal API → _notify_all()
  │
  ├── VIP Private Channel   → สัญญาณ real-time + AI CIO analysis
  ├── Public Channel         → สัญญาณดีเลย์ 1 ชม. (เหยื่อล่อ)
  └── Direct Message (1:1)   → สำหรับ user ที่กด /start
```

ตัวอย่างข้อความที่ bot ส่ง:

```
🟢 LONG NVDA — 15m
━━━━━━━━━━━━━━━━━━
📍 Entry:  $182.00 – $182.50
🎯 TP:     $187.75 (+3.1%)
🛡️ SL:     $179.56 (-1.3%)
⚖️ R:R:    1:2.5
━━━━━━━━━━━━━━━━━━
🏄 Trend Following
📰 NVDA beats Q2 EPS by 15%...
🧠 ML: 76 | Conf: 81%
━━━━━━━━━━━━━━━━━━
🤖 AI CIO:
"Strong catalyst aligned with VWAP pullback..."
```

---

## Setup ทีละขั้น

### ขั้นที่ 1: สร้าง Bot ผ่าน @BotFather

1. เปิด Telegram → ค้นหา **@BotFather** → กด Start
2. พิมพ์ `/newbot`
3. ตั้งชื่อ: `Quant Agent Signal`
4. ตั้ง username: `quant_agent_signal_bot` (ต้องลงท้ายด้วย `_bot`)
5. BotFather จะตอบกลับพร้อม **token**:

```
Done! Congratulations on your new bot.
Use this token to access the HTTP API:
1234567890:ABCdefGHIjklMNOpqrsTUVwxyz
```

6. คัดลอก token → ใส่ใน `.env`:

```bash
TELEGRAM_BOT_TOKEN=1234567890:ABCdefGHIjklMNOpqrsTUVwxyz
```

#### ตั้งค่าเพิ่มใน BotFather (แนะนำ)

```
/setdescription → AI-powered stock signal bot — 15m VWAP strategy
/setabouttext   → Quant Agent Signal Bot by [Your Name]
/setcommands    →
start - เริ่มใช้งาน
status - ดูสถานะ VIP
stats - ดูสถิติวันนี้
help - วิธีใช้งาน
```

### ขั้นที่ 2: สร้าง Channels

#### 2a. VIP Private Channel

1. Telegram → New Channel
2. ชื่อ: `Quant Agent VIP Signals`
3. ตั้งเป็น **Private** (invite link only)
4. **เพิ่ม bot เป็น admin** → ให้สิทธิ์ "Post Messages"
5. ส่งข้อความอะไรก็ได้ใน channel (เพื่อให้ bot เห็น chat_id)

#### 2b. Public Channel (Optional — เหยื่อล่อ)

1. New Channel → ชื่อ: `Quant Agent Free Signals`
2. ตั้งเป็น **Public** → username เช่น `@quant_agent_free`
3. เพิ่ม bot เป็น admin เช่นกัน
4. ส่งข้อความ 1 ข้อความ

### ขั้นที่ 3: หา Chat ID

#### วิธี A: ใช้ setup script (แนะนำ)

```bash
python platform/telegram_setup.py
```

Script จะแสดง chat_id ทั้งหมดที่ bot เห็น

#### วิธี B: ใช้ API โดยตรง

```bash
# ดึง updates (หลังส่งข้อความใน channel แล้ว)
curl "https://api.telegram.org/bot<TOKEN>/getUpdates" | python -m json.tool

# หา chat.id ในผลลัพธ์:
# "chat": { "id": -1001234567890, "title": "Quant Agent VIP", "type": "channel" }
```

#### วิธี C: ใช้ @userinfobot

1. Forward ข้อความจาก channel ไปหา @userinfobot
2. Bot จะตอบ chat_id กลับมา

### ขั้นที่ 4: ใส่ Chat IDs ใน .env

```bash
# ── Telegram
TELEGRAM_BOT_TOKEN=1234567890:ABCdefGHIjklMNOpqrsTUVwxyz
TELEGRAM_VIP_CHAT_ID=-1001234567890
TELEGRAM_PUBLIC_CHAT_ID=-1009876543210

# ── Dashboard URL (สำหรับลิงก์ในข้อความ)
DASHBOARD_URL=https://signal.yourdomain.com
```

**หมายเหตุ:** Chat ID ของ channel จะขึ้นต้นด้วย `-100`

### ขั้นที่ 5: ทดสอบ

```bash
# ── ทดสอบทีละขั้น (interactive)
python platform/telegram_setup.py

# ── ทดสอบส่งสัญญาณจำลองทันที
python platform/telegram_quick_test.py

# ── ส่งทุกแบบ (signal + cancel + digest)
python platform/telegram_quick_test.py --type all

# ── ส่งไป chat_id เฉพาะ
python platform/telegram_quick_test.py --chat-id -1001234567890
```

### ขั้นที่ 6: Webhook (Production)

เมื่อ deploy บน VPS + มี domain + SSL แล้ว:

```bash
# ── ตั้ง webhook ให้ Telegram ส่ง update มาที่ server ของเรา
curl -X POST "https://api.telegram.org/bot<TOKEN>/setWebhook" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://signal.yourdomain.com/webhook/telegram"}'

# ── ตรวจสถานะ webhook
curl "https://api.telegram.org/bot<TOKEN>/getWebhookInfo"

# ── ยกเลิก webhook (กลับไป polling)
curl "https://api.telegram.org/bot<TOKEN>/deleteWebhook"
```

Webhook ทำให้ bot รับ `/start`, `/status` commands จาก user ได้
FastAPI endpoint `/webhook/telegram` ใน `signal_api.py` รองรับอยู่แล้ว

---

## Architecture สรุป

```
signal_api.py
  │
  ├── POST /api/signals  (รับจาก Signal Bridge)
  │     └── _notify_all()
  │           ├── notifier_telegram.send_signal_telegram()
  │           │     → VIP user (1:1 direct message)
  │           ├── notifier_telegram.send_signal_to_vip_channel()
  │           │     → VIP Private Channel (broadcast)
  │           └── notifier_telegram.send_signal_to_public_channel()
  │                 → Public Channel (delayed, no LLM comment)
  │
  ├── POST /admin/cancel/{id}
  │     └── _notify_cancel()
  │           └── send_cancel_telegram() → ทุก VIP
  │
  └── POST /webhook/telegram  (รับจาก Telegram)
        ├── /start → register user
        └── /status → send status
```

---

## ข้อความที่ bot ส่งได้

| ประเภท | Function | ไปที่ไหน | เมื่อไหร่ |
|---|---|---|---|
| Signal (VIP) | `send_signal_telegram(is_vip=True)` | VIP channel + 1:1 | ทุกครั้งที่มี signal ใหม่ |
| Signal (Public) | `send_signal_to_public_channel()` | Public channel | ดีเลย์ 1 ชม. |
| Cancel | `send_cancel_telegram()` | ทุก VIP | Admin กด cancel |
| Daily Digest | `send_daily_digest_to_public()` | Public channel | สรุปท้ายวัน |

---

## ปรับแต่ง

### เพิ่ม Delayed Signal สำหรับ Public Channel

ตอนนี้ `_notify_all()` ใน `signal_api.py` ส่งเฉพาะ VIP
ถ้าต้องการส่งดีเลย์ไป Public channel ด้วย ให้เพิ่ม scheduled task:

```python
# เพิ่มใน signal_api.py หรือ cron job แยก
import asyncio
from datetime import timedelta

async def send_delayed_public(signal_id: str):
    """รอ 1 ชม. แล้วส่งไป Public Channel"""
    await asyncio.sleep(3600)  # 1 hour
    _, SF = init_db(DB_URL)
    session = SF()
    sig = session.query(Signal).filter(Signal.signal_id == signal_id).first()
    if sig and sig.status != "CANCELLED":
        send_signal_to_public_channel(sig.to_dict())
    session.close()
```

### เพิ่ม Inline Keyboard (ปุ่มกด)

```python
# ใน notifier_telegram.py — เพิ่ม reply_markup
def send_signal_with_buttons(chat_id, signal):
    html = build_signal_html(signal)
    payload = {
        "chat_id": chat_id,
        "text": html,
        "parse_mode": "HTML",
        "reply_markup": {
            "inline_keyboard": [[
                {"text": "📈 ดูกราฟ", "url": f"{DASHBOARD_URL}/signal/{signal['signal_id']}"},
                {"text": "📊 Dashboard", "url": DASHBOARD_URL},
            ]]
        }
    }
    requests.post(f"{TG_API_URL}/sendMessage", json=payload, timeout=10)
```

---

## Troubleshooting

| ปัญหา | สาเหตุ | แก้ไข |
|---|---|---|
| `TELEGRAM_BOT_TOKEN not set` | ไม่ได้ใส่ token ใน .env | สร้าง bot ที่ @BotFather แล้วใส่ token |
| `chat not found` | Bot ไม่ได้เป็น admin ใน channel | เพิ่ม bot เป็น admin + ให้สิทธิ์ Post Messages |
| `bot was blocked by the user` | User บล็อก bot | User ต้อง unblock เอง |
| `403: Forbidden` | Bot ถูกลบออกจาก channel | เพิ่ม bot กลับเข้า channel |
| ส่งได้แต่ไม่เห็นข้อความ | Channel notification ถูกปิด | ตรวจ notification settings ใน Telegram |
| Webhook error 502 | FastAPI ยังไม่ start | `pm2 restart signal-api` |
| `getUpdates` ว่างเปล่า | Webhook ถูกตั้งอยู่ | ลบ webhook: `deleteWebhook` แล้วลองใหม่ |
